#include <iostream>

using namespace std;

int main()

{
	float peso,altura,imc;  //decalracao variavel ponto flutuante 
	string mensagem;    //decalracao variavel literal

	cout << "================ CAlCULO IMC ================";
	cout << "\nPeso em kg: ";
	cin >> peso;
	cout << "altura em metros: ";
	cin >> altura;
	

	imc = peso/(altura * altura); //Formula imc
    
	
	if(imc > 35)
	{
		mensagem = "Obesidade Morbita";
	}
		else
		{
			if(imc > 30 )
			{
				mensagem = "Obesidade";
			}
				else
				{
					if(imc > 25)
					{
						mensagem = "Excesso de peso";
					}
						else
						{
							if(imc >= 20)
							{
								mensagem = "Peso Normal";
							}
								else
								{
									mensagem = "Abaixo do peso Ideal";
								}
						}			
				}
		}
	cout <<"\n\n"<<mensagem<<endl;  //exibicao dos resultados obtidos
}
