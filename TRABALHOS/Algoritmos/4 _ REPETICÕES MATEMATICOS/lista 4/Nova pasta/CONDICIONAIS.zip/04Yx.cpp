#include <iostream>

using namespace std;

int main ()
{
	int x,y; //declaradao das variaveis 
	
	cout << "Digite um numero qualquer: ";
	cin >> x;
	
	if( x < 1)
	{
		y = x; 
	}
		
		else
		{
			if( x > 1 )
			{
				y = x*2; 	
			}
			
				else // se nao for maior ou menor que 1 ,sera igual a 1 !!!
				{
					y = 0;
				}
		}
		cout << y;
}
