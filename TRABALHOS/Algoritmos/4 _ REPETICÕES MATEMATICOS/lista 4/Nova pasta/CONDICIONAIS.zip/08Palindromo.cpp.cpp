#include<iostream>
using namespace std;

int main()
{
	int x,a,b,c,d,e; // declaracao das variaveis
	
	cout << "digite um numero de 5 algarismos e tecle 'Enter'"<<endl;
	cin >> x;
	
	// decompor o numero de forma a separar cada algarismo em uma variavel....
	a = x/10000;
		x = x%10000;
	
	b = x/1000;
		x = x%1000;
	
	c = x/100;
		x = x%100;
		
	d = x/10;
		x = x%10;
	
	e=x;
		
	if(a==e && b==d) // verificar se e palindromo ou nao
	{
		cout << "Este numero eh palindromo !"<<endl; // exibicao da mensagem se palindromo
	}
		else
		{
		cout << "este numero nao eh palindromo ..."<<endl; // exibicao da mensagem se nao palindromo
		}
	
	return (0);
}
