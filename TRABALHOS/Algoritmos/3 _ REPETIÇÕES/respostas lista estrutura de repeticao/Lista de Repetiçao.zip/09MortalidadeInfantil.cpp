#include <iostream>

using namespace std;

int main()
{
	//declaracao das variaveis necessarias 
	int qntd,tempo;
	string sexo;
	float a,b,c,masc,tempo24m,mortes;
	//variaveis de inicializacao
	mortes = 0;
	masc = 0;
	tempo24m = 0;
	
	cout << "****Para indicar que nao existem mais criancas mortas, Digite 'vazio' em Sexo****"<<endl;	//informando o flag para o usuario
	cout << "Numero de Criancas nascidas no Periodo: "; // dado inicial
	cin >>qntd;
	
	cout << "\n\nSexo da Crianca morta: ";  // obtencao de dados 
	cin >>sexo;
	
		while( sexo[0] != 'V' && sexo[0] != 'v' && sexo[0] != 'M' && sexo[0] != 'm' && sexo[0] != 'f' && sexo[0] != 'F' )  //validacao dos dados 
		{
			cout << "DIGITE UM SEXO VALIDO (M)MASCULINO OU (F)FEMININO"<<endl;
			cin.ignore();
			cin >>sexo;
		}
	
	while(sexo[0] != 'V' && sexo[0] != 'v') // enquanto sexo for diferente do flag , o processo se repetira 
	{
		cout << "Tempo de vida em MESES: ";
		cin >>tempo;
		cout <<"_________________________________________"<<endl;
		
		mortes++;
		
		if(sexo[0] == 'M' || sexo[0] == 'm')
		{
			masc++;
		}
		
		if (tempo <= 24)
		{
			tempo24m++;
		}
		
		cout << "Sexo da Crianca morta: ";
		cin >> sexo;
	
		while(sexo[0] != 'M' && sexo[0] != 'm' && sexo[0] != 'f' && sexo[0] != 'F' && sexo[0] != 'V' && sexo[0] != 'v')//validacao dos dados 
		{
			cout << "DIGITE UM SEXO VALIDO (M)MASCULINO OU (F)FEMININO"<<endl;
			cin >>sexo;
		}
	}
	// calculo do que foi pedido
	a = (mortes * 100)/qntd;  
	b = (masc * 100)/qntd;
	c = (tempo24m * 100)/qntd;
	
	//exibicao dos dados de saida 
	cout << "\n\n==> Porcentagem de criancas mortas: "<<a<<"%"<<endl;
	cout << "==> Porcentagem de criancas do sexo masculino mortas: "<<b<<"%"<<endl;
	cout << "==> Porcentagem de criancas que vivem ate 24 meses: "<<c<<"%"<<endl;	
}
