#include <iostream>

using namespace std;

int main()
{
	int num_operario,fem,masc,somapecasM,somapecasF,aux,num_operariom,mediamasc,mediafem,npecas; //declaracao das variaveis interias 
	float salariominimo,maiorm,totpagamentos,totpecas,salario,maior; //declaracao das variareis reais 
	char sexo,sexom; //declaracao das variaveis do tipo caracter

	//variaveis de inicializacao
	maior = -1;
	somapecasM = 0;
	somapecasF = 0;
	fem = 0;
	masc = 0;
	totpagamentos = 0;
	totpecas = 0;	
	//dados iniciais
	cout << "Salario minimo: R$";
	cin >>salariominimo;
	
	cout << "\nNumero do Operario: ";
	cin >>num_operario;
	
	while(num_operario != 0)
	{
		cout << "Sexo do operario (m)masculino ou (f)feminino: ";
		cin >>sexo;
		
		cout << "Numero de pecas frabicadas no mes: ";
		cin >>npecas;
		
		if(sexo == 'M' || sexo == 'm')
		{
			masc++; // qntidade de homens
			somapecasM = somapecasM + npecas; //soma das pecas fabricadas pelos machos
		}
		else
		{
			fem++; //qntidade de mulheres 
			somapecasF = somapecasF + npecas;  //soma das pecaas fabricada pelas mulheres 
		}
		
			if(npecas <= 30)
			{
				salario = salariominimo;  //salario referente ao numero de pecas 
			}
			else
			{
				if(npecas > 30 && npecas <= 35)
				{
					aux = npecas - 30;
					salario = salariominimo + (aux * 0.03 * salariominimo);//salario referente ao numero de pecas 
				}
				else
				{
					aux = npecas - 30;
					salario = salariominimo + (aux * 0.05 * salariominimo);//salario referente ao numero de pecas 
				}
			}			
				totpagamentos = totpagamentos + salario; //soma dos salarios
				totpecas = totpecas + npecas; //total de pecas 
				
					if(salario > maior)
					{
						maior = salario;
						sexom = sexo;
						num_operariom = num_operario;
					}
		cout << "\n|--------------------------------------------"<<endl; //bike de pedreiro
		cout << "|  ==> OPERARIO DE NUMERO: "<<num_operario<<endl;
		cout << "|  ==> SALARIO: R$"<<salario<<endl;
		cout << "|--------------------------------------------"<<endl; //penteadeira de puta 
		cout << "\nNumero do Operario: ";
		cin >>num_operario;
	}
			mediamasc = somapecasM/masc;
			mediafem = somapecasF/fem;
			//exibicao dos dados finais 
			cout << "\n\nTotal da folha de pagamento do mes: R$"<<totpagamentos<<endl;
			cout << "Total de pecas produzidas: "<<totpecas<<endl;
		
			cout << "\n------>Media de pecas produzidas por homens: "<<mediamasc<<endl;
			cout << "------>Media de pecas produzidas por mulheres: "<<mediafem<<endl;
		
			cout << "\n\n==========FUNCIONARIO DO MES==========="<<endl;
			cout << "==>NUMERO DO OPERARIO "<<num_operariom<<endl;
			cout << "==>SEXO DO OPERARIO : "<<sexom<<endl;		
			cout << "==>SALARIO: R$"<<maior<<endl;	
}
