#include <iostream>

using namespace std;

int main()
{
	float lucro,lucromax,x,y;
	int operarios_stan,operarios_lux,homens_stan,homens_lux,radios_stan,radios_lux,operarios;
	cout.precision (2);  // precisao das casas decimais 
	lucromax = 0;
	cout << "Preco do radio standard: R$";
	cin >>x;	
	cout << "Preco do radio luxo: R$";
	cin >>y;
	operarios = 40;
	homens_stan = 8; // minimo que standard pode assumir , pois 40(total) - 32(luxo) = 8 (standard) e o max que ele pode atingir e 24 operarios 
	while(homens_stan <= 24)
	{
		homens_lux = operarios - homens_stan;
		lucro = (homens_stan * x) + ((homens_lux/2)*y);
		
		if(lucro > lucromax)
		{
			lucromax = lucro;
			operarios_stan = homens_stan;
			operarios_lux = homens_lux;
		}
		homens_stan++;
	}
	
	homens_lux = 16; // minimo que pode ser atribuido pois 40(total) - 24(total de standard) = 16 (minimo lux) e o max e 32 operarios
	while (homens_lux <= 32)
	{
		homens_stan = operarios - homens_lux;
		lucro = (homens_stan * x) + ((homens_lux/2)*y);
		
		if(lucro > lucromax) //
		{
			lucromax = lucro;
			operarios_stan = homens_stan;
			operarios_lux = homens_lux;
		}
		homens_lux++;	
	}
	radios_stan = homens_stan; //quantiodade radios standard
	radios_lux = homens_lux/2;  // quantidade de radios luxo

	//exibicao dos resultados de saida
	cout << "\n------------------------------------------------------------"<<endl;
	cout <<fixed<<"==>Lucro Maximo: R$"<<lucromax<<endl;
	cout << "==>Numero de operarios da linha STANDARD: "<<operarios_stan<<endl;
	cout << "==>Numero de operarios da linha LUXO: "<<operarios_lux<<endl; 
	
	cout << "\n==>Linha STANDARD: "<<radios_stan<<" Radios"<<endl;
	cout << "==>Linha LUXO: "<<radios_lux<<" Radios"<<endl;
	cout << "------------------------------------------------------------"<<endl;                                                                                                                                                                                                                                                                                                                                              
}
