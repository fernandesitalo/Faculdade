#include <iostream>

using namespace std;

int main()
{
	float  c,f; // declaracao das variaceis reais 
	int i;   // declaracao das variaveis inteiras 	
	
	f = 50;    // dados iniciais no inicio do progama 
	
	cout << "    CENTIGRADOS---------------------------FARENHEIT"<<endl;
	
	
	for (i = 0; i <= 100 ; i = i + 1) // comando para(variaveil de inicializacao ; condicao ;  incremento )
	{
		c = (5 * (f - 32) )/ 9;  // transforma��o centigrtados para farenheit 	
		cout <<"     "<<c<<"  C                             "<<f<<" F"<<endl;  // exibicao da tabela 
		f = f + 1; // proximo grau em farhenit 
	} 
	
	return 0;
	
}
