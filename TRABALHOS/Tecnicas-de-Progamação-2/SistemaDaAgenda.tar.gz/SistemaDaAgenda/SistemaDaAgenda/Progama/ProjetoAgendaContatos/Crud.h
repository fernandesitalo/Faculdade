#ifndef CRUD_H
#define CRUD_H


class Crud
{
public:
    Crud();
};

#endif // CRUD_H