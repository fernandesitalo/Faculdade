PDRTJS_2088596_post_1053.avg_rating = 0;
PDRTJS_2088596_post_1053.votes = 0;		
PDRTJS_settings_2088596_post_1053= {			"type" : "stars",			"size" : "sml",			"star_color" : "yellow",			"custom_star" : "",			"font_size" : "",			"font_line_height" : "16px",			"font_color" : "",			"font_align" : "left",			"font_position" : "right",			"font_family" : "",			"font_bold" : "normal",			"font_italic" : "normal",			"text_votes" : "Votes",			"text_rate_this" : "Rate This",			"text_1_star" : "Very Poor",			"text_2_star" : "Poor",			"text_3_star" : "Average",			"text_4_star" : "Good",			"text_5_star" : "Excellent",			"text_thank_you" : "Thank You",			"text_rate_up" : "Rate Up",			"text_rate_down" : "Rate Down"		};
PDRTJS_2088596_post_1053.init();		
PDRTJS_2088596_post_1053.token='deb7a38e7d7829fa4c09cd80e121c58b';
/*2088596,_post_1053,wp-post-1053,3140905383,0-0*/