PDRTJS_6492616_comm_158.nero_up = 1;
PDRTJS_6492616_comm_158.nero_dn = 0;		
PDRTJS_settings_6492616_comm_158= {"type" : "nero","size" : "sml","star_color" : "hand","custom_star" : "","font_size" : "","font_line_height" : "16px","font_color" : "","font_align" : "left","font_position" : "right","font_family" : "","font_bold" : "normal","font_italic" : "normal","text_vote" : "Vote","text_votes" : "Votes","text_rate_this" : "Rate This","text_1_star" : "Very Poor","text_2_star" : "Poor","text_3_star" : "Average","text_4_star" : "Good","text_5_star" : "Excellent","text_thank_you" : "Thank You","text_rate_up" : "Rate Up","text_rate_down" : "Rate Down"};
PDRTJS_6492616_comm_158.init();		
PDRTJS_6492616_comm_158.token='a93f57437fa25fa40340fc66e394e78d';
/*6492616,_comm_158,wp-comment-158,3140905383,1-0*/