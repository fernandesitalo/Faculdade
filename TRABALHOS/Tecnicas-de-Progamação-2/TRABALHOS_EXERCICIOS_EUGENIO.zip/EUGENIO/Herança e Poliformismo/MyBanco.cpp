#include <iostream>
#include <stdio.h>

class conta
{
private:	
	std::string nome;
	long long cpf;
	long long numeroDaconta;
	int agencia;
	double saldo;

public:	
	void setCpf(long long &cpf_){cpf = cpf_;}
	long long getCpf(){return cpf;}
	
	void setNome(std::string &name){nome = name;}
	void getNome(std::string &name){name = nome;}
	
	void setNumeroDaConta(long long &num){numeroDaconta = num;}
	long long getNumeroDaConta(){return numeroDaconta;}
	
	void setAgencia(int &ag){agencia = ag;}
	int getAgencia(){return agencia;}
	
	void setSalto(double &valor){saldo = valor;}
	double getSaldo(){return saldo;}	
};

class ContaPoupanca : public conta
{
private:	
	float rendimentoMensal;
public:	
	void setNovoRendimento(float &rend){rendimentoMensal = rend;}
};


class ContaCorrenteSimples : public conta
{
private:
	double limite;
public:
	ContaCorrenteSimples(conta());	
	void setLimite(double &lim){limite = lim;}
	double getLimite(){return limite;}
};


class ContaCorrenteEspecial : public conta
{
public:	
	ContaCorrenteEspecial(conta());
};



int main(){}

