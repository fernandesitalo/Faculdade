#include <iostream>
#include <stdio.h>
using namespace std;

class base{
private:
    int a;
public:
    int b;
protected: // defalt
    int c;
};


class derivada : private base
{
private:
    int k;

public:
    void f1()
    {
        //a = 0;// A classe Derivada não tem acesso aos membros privados da Base
        c = 0;  // A classe Derivada tem acesso aos membros protegidos da Base
        b = 0;  // A classe Derivada tem acesso aos membros públicos da Base
    }


protected:/// não existe na main!
    void f2()
    {
        k = 1 + c; // c e protected na classe base, como aqui se trata da deriva, entao temos acesso
    }
};

int main(){

    derivada a;

}
