#include <iostream>
#include <string.h>
#define TAMANHO 100

/*
METODO OU ATRIBUTO

Private:	somente a própria classe pode acessar o método/atributos.
			Classes derivadas ou que possui um objeto da classe não 
			podem acessar;

Protected:	somente a própria classe e suas CLASSES DERIVADAS é que
			podem ter acesso aos métodos e atributos. Classes que 
			possui um objeto da classe não tem acesso. /// NAO TEM ACESSO NA MAIN
			

Public: 	todas as classes podem ter acesso.
*/







class Pessoa{ // CLASSE PESSOA E A CLASSE BASE 
private:
	char nome[TAMANHO];
	char endereco[TAMANHO];
	char email[TAMANHO];
	long long telefone;
	
public:

	Pessoa(){ nome[0] = '\0', email[0] = '\0', endereco[0] = '\0', telefone = 0;}
	
	void setNome(char *nome_){strcpy(nome,nome_);}
	void getNome(char *nome_){strcpy(nome_,nome);}
	
	void setEndereco(char *endereco_){strcpy(endereco,endereco_);}
	void getEndereco(char *endereco_){strcpy(endereco,endereco_);}
	
	void setEmail(char *email_){strcpy(email,email_);}
	void getEmail(char *email_){strcpy(email_,email);}
	
	void setTelefone(long long telefone_){telefone = telefone_;}
	long long getTelefone(){return telefone;}
};


class Estudante : public Pessoa // CLASSE ESTUDANTE HEDARA TUDO QUE E PUBLIC E TUDO QUE É PROTECTED 
{								// LEMBRANDO QUE O USUARIO DA CLASSE SO TEM ACESSO A PARTE PUBLIC
								// PROTECTED E SO PRA QUEM HERDAR DA CLASSE BASE		
private:
	long long matricula;
	char curso;
	char campus;
	
public:
	Estudante() : Pessoa(){};
	
	void setMatricula(long long matricula_){matricula = matricula_;}
	long long getMatricula(){return matricula;}
	
	void setCurso(char &curso_){curso = curso_;}
	void getCurso(char &curso_){curso_ = curso;}

	void setCampus(char &campus_){campus = campus_;}
	void getCampus(char &campus_){campus_ = campus;}
};

class Trabalhador : public Pessoa
{
private:
	char funcao;
	char departamento;
	double salario;
public:
	void setFuncao(char &funcao_){funcao = funcao_;}
	void getFuncao(char &funcao_){funcao_ = funcao;}
	
	void setDepartamento(char &departamento_){departamento = departamento_;}
	void getDepartamento(char &departamento_){departamento_ = departamento;}
	
	void setSalario(double &salario_){salario = salario_;}
	double getSalario(){return salario;}
};

class Graduado : public Estudante // acesso publico, isto é,
{
private:	
	int anoDaConclusao;
	int anoDaColacaoDeGrau;
	int numeroDoDiploma;
public:
	void setAnoDaConclusao(int &aux_){anoDaConclusao = aux_;}
	int getAnoDaConclusao(){return anoDaConclusao;}
	
	void setAnoDaColacaoDeGrau(int &aux_){anoDaColacaoDeGrau = aux_;}
	int getAnoDaColacaoDeGrau(){return anoDaColacaoDeGrau;}
	
	void setNumeroDoDiploma(int &aux_){numeroDoDiploma = aux_;}
	int getNumeroDoDiploma(){return numeroDoDiploma;}
};



int main(){
	
	return 0;
}

