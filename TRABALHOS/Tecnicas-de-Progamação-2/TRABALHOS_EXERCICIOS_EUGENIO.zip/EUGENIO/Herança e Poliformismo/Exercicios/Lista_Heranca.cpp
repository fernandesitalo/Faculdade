#include <iostream>
#include <string.h>


class Pessoa{ // CLASSE PESSOA E A CLASSE BASE 
private:
	std::string nome;
	std::string endereco;
	std::string email;
	long long telefone;
	
public:

	Pessoa(){ nome = email = endereco = "", telefone = 0;}
	
	void setNome(std::string &nome_){nome = nome_;}
	void getNome(std::string &nome_){nome_ = nome;}
	
	void setEndereco(std::string &endereco_){endereco = endereco_;}
	void getEndereco(std::string &endereco_){endereco = endereco_;}
	
	void setEmail(std::string &email_){email = email_;}
	void getEmail(std::string &email_){email_ = email;}
	
	void setTelefone(long long telefone_){telefone = telefone_;}
	long long getTelefone(){return telefone;}
};


//class nomeClasseFilho : acesso nomeClassePai
///public – todos os membros public e protected da
///classe básica tornam-se public e protected na classe
///derivada

class Estudante : public Pessoa
{
private:
	long long matricula;
	std::string curso;
	std::string campus;
	
public:
	Estudante() : Pessoa(){};
	
	void setMatricula(long long matricula_){matricula = matricula_;}
	long long getMatricula(){return matricula;}
	
	void setCurso(std::string &curso_){curso = curso_;}
	void getCurso(std::string &curso_){curso_ = curso;}

	void setCampus(std::string &campus_){campus = campus_;}
	void getCampus(std::string &campus_){campus_ = campus;}
};

class Trabalhador : public Pessoa
{
private:
	std::string funcao;
	std::string departamento;
	double salario;
public:
	void setFuncao(std::string &funcao_){funcao = funcao_;}
	void getFuncao(std::string &funcao_){funcao_ = funcao;}
	
	void setDepartamento(std::string &departamento_){departamento = departamento_;}
	void getDepartamento(std::string &departamento_){departamento_ = departamento;}
	
	void setSalario(double &salario_){salario = salario_;}
	double getSalario(){return salario;}
};

class Graduado : public Estudante
{
private:	
	int anoDaConclusao;
	int anoDaColacaoDeGrau;
	int numeroDoDiploma;
public:
	void setAnoDaConclusao(int &aux_){anoDaConclusao = aux_;}
	int getAnoDaConclusao(){return anoDaConclusao;}
	
	void setAnoDaColacaoDeGrau(int &aux_){anoDaColacaoDeGrau = aux_;}
	int getAnoDaColacaoDeGrau(){return anoDaColacaoDeGrau;}
	
	void setNumeroDoDiploma(int &aux_){numeroDoDiploma = aux_;}
	int getNumeroDoDiploma(){return numeroDoDiploma;}
};







int main(){
	
	return 0;
}
