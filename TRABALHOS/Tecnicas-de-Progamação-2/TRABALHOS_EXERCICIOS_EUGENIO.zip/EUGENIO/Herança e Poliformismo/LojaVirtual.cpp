#include <iostream>
#include <stdio.h>
#include <string.h>

class produto
{
private:
	long long codigo;
	std::string descricao;
	float precoDeVenda;
	/// tipo do produto
public:	
	
};


class Livros : public produto
{
private:
	std::string autor;
	std::string tradutor;
	std::string editora;
	int anoDaPublicacao;
public:
	void setAutor(std::string &Autor__){ autor = Autor__ ;}
	void getAutor(std::string &Autor__){ Autor__ = autor ;}
	
	void setTradutor(std::string &Tradutor__){ tradutor = Tradutor__ ;}
	void getTradutor(std::string &Tradutor__){ Tradutor__ = tradutor ;}

	void setEditora(std::string &Editora__){ editora = Editora__ ;}
	void getEditora(std::string &Editora__){ Editora__ = editora; }
	
	void setAnoDaPublicacao(int &aux_){anoDaPublicacao = aux_;}
	int getAnoDapublicacao(){return anoDaPublicacao;}
	
}; 

class CDs : public produto
{
private:
	std::string nomeDoAlbum;
	std::string banda;
	std::string cantor;
	std::string generoMusical;
public:
	
	CDs(){
		produto();
		nomeDoAlbum = banda = cantor = generoMusical = '\0';
	}	

	void setNomeDoAlbum(std::string &NomeDoAlbum__){ nomeDoAlbum = NomeDoAlbum__ ;}
	void getNomeDoAlbum(std::string &NomeDoAlbum__){ NomeDoAlbum__ = nomeDoAlbum ;}
	
	void setBanda(std::string &Banda__){ banda = Banda__ ;}
	void getBanda(std::string &Banda__){ Banda__ = banda ;}
	
	void setCantor(std::string &Cantor__){ cantor = Cantor__ ;}
	void getCantor(std::string &Cantor__){ Cantor__ = cantor ;}
	
	void setGeneroMusical(std::string &GeneroMusical__){ generoMusical = GeneroMusical__ ;}
	void getGeneroMusical(std::string &GeneroMusical__){ GeneroMusical__ = generoMusical ;}
};

class Notebook : public produto
{
private:
	std::string marca;
	std::string modelo;
	std::string ram;
	std::string capacidadeDoHD;
	std::string processador;
	std::string tamanhoDaTela;
	std::string sistemaOperacional;	
public:	
	
	void setMarca(std::string & marca){this->marca = marca;}
	void getMarca(std::string & marca){marca = this->marca;}
	
	void setModelo(std::string &modelo){this->modelo = modelo;}
	void getModelo(std::string &modelo){modelo = this->modelo;}
	
	void setRam(std::string &ram){this->ram = ram;}
	void getRam(std::string){ram = this->ram;}
	
	void setCapacidadeDoHD(std::string &hd){this->capacidadeDoHD = hd;}
	void getCapacidadeDoHD(std::string &hd){hd = this->capacidadeDoHD;}
	
	void setProcessador(std::string &processador){this->processador = processador;}
	void getProcessador(std::string &processador){processador = this->processador;}
	
	void setTamanhoDaTela(std::string &tela){this->tamanhoDaTela = tela;}
	void getTamanhoDaTela(std::string &tela){tela = this->tamanhoDaTela;}	
	
	void setSistemaOperacional(std::string &SO){this->sistemaOperacional = SO;}
	void getSistemaOperacional(std::string &SO){SO = sistemaOperacional;}	
};

int main(){
	
	
	return 0;
}
