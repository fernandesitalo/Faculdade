#include <iostream>



class Pessoa{ // CLASSE PESSOA E A CLASSE BASE 
private:
	std::string nome;
	std::string endereco;
	std::string email;
	long long telefone;
	
public:

	Pessoa(){ nome = email = endereco = "", telefone = 0;}
	
	void setNome(std::string &nome_){nome = nome_;}
	void getNome(std::string &nome_){nome_ = nome;}
	
	void setEndereco(std::string &endereco_){endereco = endereco_;}
	void getEndereco(std::string &endereco_){endereco = endereco_;}
	
	void setEmail(std::string &email_){email = email_;}
	void getEmail(std::string &email_){email_ = email;}
	
	void setTelefone(long long telefone_){telefone = telefone_;}
	long long getTelefone(){return telefone;}
	
	virtual float CalcularImposto() = 0;
};

#define MASCULINO true
#define FEMININO false

class PessoaFisica : public Pessoa
{//CPF, sexo, calcular imposto de renda.
private:
	long long cpf;
	float rendaBruta;
	bool sexo;	
public:
	void setCpf(long long &cpf_){cpf = cpf_;}
	long long getCpf(){return cpf;}
	
	void setSexo(bool &sex){sexo = sex;}
	bool getSexo(){return sexo;}
	
	void setRendaBruta(float &Renda){rendaBruta = Renda;}
	float getRendaBruta(){return rendaBruta;}
	
	float CalcularImposto(){
		if(rendaBruta <= 1400) return 0;
		if(rendaBruta <= 2100) return rendaBruta*0.10;
		if(rendaBruta <= 2800) return rendaBruta*0.15;
		if(rendaBruta <= 3600) return rendaBruta*0.25;
		return rendaBruta*0.30;
	}
};


class PessoaJuridica : public Pessoa
{//CNPJ, razão social, calcular imposto de renda.
private:
	long long cnpj;
	std::string razaoSocial;
	float RendaBrutaAnual;	
public:
	float CalcularImposto(){return RendaBrutaAnual*0.10;}
	
	// set e get cnpj
	// set get razao Social	
};


int main(){
	
}
