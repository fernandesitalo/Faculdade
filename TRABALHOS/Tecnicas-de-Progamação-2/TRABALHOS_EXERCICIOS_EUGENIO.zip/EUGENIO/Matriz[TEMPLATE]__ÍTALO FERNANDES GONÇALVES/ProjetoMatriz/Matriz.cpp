#include "Matriz.h"
#include <QInputDialog>
#include <QMessageBox>





/// SOBRECARGA DO OPERADOR DE SUBTRACAO DE DUAS MATRIZES
Matriz *Matriz::operator-(const Matriz * const mat) const


bool Matriz::operator==(const Matriz * const mat) const
{



bool Matriz::operator!=(const Matriz * const mat) const



Matriz *Matriz::operator*(const Matriz * const mat) const






}

//fim
