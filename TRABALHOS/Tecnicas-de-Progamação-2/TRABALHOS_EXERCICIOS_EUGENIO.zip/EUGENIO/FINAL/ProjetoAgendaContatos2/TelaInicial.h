#ifndef TELAINICIAL_H
#define TELAINICIAL_H

#include <QDialog>

namespace Ui {
class TelaInicial;
}

class TelaInicial : public QDialog
{
    Q_OBJECT

public:
    explicit TelaInicial(QWidget *parent = 0);
    ~TelaInicial();

private slots:
    void on_pushButtonIncluir_clicked();

private:
    Ui::TelaInicial *ui;
};

#endif // TELAINICIAL_H
