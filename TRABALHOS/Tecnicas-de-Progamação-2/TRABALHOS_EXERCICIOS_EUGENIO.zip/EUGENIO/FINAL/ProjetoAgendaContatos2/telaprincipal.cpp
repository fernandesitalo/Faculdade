#include "telaprincipal.h"
#include "ui_telaprincipal.h"
#include "contatodao.h"
#include <QTableWidgetItem>
#include "infcontatos.h"
#include "criarcategoria.h"
#include "CategoriaDAO.h"
#include "CategoriaContato.h"

TelaPrincipal::TelaPrincipal(QWidget *parent) :
    QMainWindow(parent),ui(new Ui::TelaPrincipal)
{
    ui->setupUi(this);
    try{
        ContatoDAO DAO;
        CategoriaDAO DAO2;
        BIA::CategoriaContatoDAO DAO3;

        Contatos_Temporarios = DAO.listar(); // trazer para a memoria principal
        std::vector<std::pair<int,QString> >* vetCateg = DAO2.listar();
        for(int i = 0; i <(int)vetCateg->size() ;i++)
        {
            this->categorias.setCategoria(vetCateg->at(i).first,vetCateg->at(i).second);
        }

        // trazer para a memoria principal
        std::vector<std::pair<int,int> >  const *  CategoriasContatos   =  DAO3.listar();
        for(std::map<int,BIA::Contato>::iterator it = Contatos_Temporarios->begin();it != this->Contatos_Temporarios->end();it++)
        {
            for(int i = 0;i<(int)CategoriasContatos->size();i++)
            {
                if(CategoriasContatos->at(i).first == it->first )
                {
                    it->second.SetCategoria(CategoriasContatos->at(i).second);
                }
            }
        }

    }catch(QString & Erro)
    {
        QMessageBox::warning(this,"OPS!",Erro);
    }
    this->Listar_Contatos_Tela();
}

TelaPrincipal::~TelaPrincipal()
{
    ContatoDAO DAO;
    CategoriaDAO DAO2;

    DAO.incluir( Contatos_Temporarios );

    // GRAVAR CATEGORIAS NO ARQUIVO
    DAO2.incluirTudo(*this->categorias.getAll());

    // GRAVAR LINKAGEM DE CONTATOS E CATEGORIA....
    /*BIA::CategoriaContatoDAO DAO3;
    for(std::map<int,BIA::Contato>::const_iterator it = Contatos_Temporarios->begin();it != this->Contatos_Temporarios->end(); ++it)
    {
      DAO3.incluir(it->second);
    }*/

    if(Contatos_Temporarios) delete Contatos_Temporarios;
    delete ui;
}

void TelaPrincipal::Listar_Contatos_Tela()
{
    ui->tableWidget_Listagem->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableWidget_Listagem->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableWidget_Listagem->setRowCount(this->Contatos_Temporarios->size());

    int linha = 0;

    for(std::map<int,BIA::Contato>::iterator it = Contatos_Temporarios->begin();
        it != Contatos_Temporarios->end();++it)
    {
        const std::vector < int >* categorias_contato = it->second.getCategorias();
        QString categ_str;
        if (categorias_contato->empty())
            categ_str = "Sem categoria!";
        else
            for (unsigned int i = 0; i < categorias_contato->size(); ++i)
                categ_str += (i ? " / " : "") + categorias.getCategoria(categorias_contato->at(i));

        ui->tableWidget_Listagem->setItem(linha, 0, new QTableWidgetItem(categ_str));
        ui->tableWidget_Listagem->setItem(linha,1,new QTableWidgetItem(it->second.getNomeCompleto()));
        this->Indice_Nomde_id[ it->second.getNomeCompleto() ] = it->first; // INCLUSAO NO INDICE !
        ++linha;
    }

    ui->tableWidget_Listagem->sortItems(1);  ////////////ORDENAÇÃO MONSTER MACHINE PLUS PLUS EXTRA HYPER POWER#
}


void TelaPrincipal::on_pushButton_IncluirContato_clicked()
{
    try{
        BIA::Contato Contato_Auxiliar;
        telaDeInclusao Tela_inclusao;
        int Flag_Add_Contato = false;

        Tela_inclusao.setObjetosTelaAnterior(&Contato_Auxiliar,&Flag_Add_Contato,&categorias);
        Tela_inclusao.ListCategorias();
        this->hide();

        Tela_inclusao.setGeometry(this->geometry());
        Tela_inclusao.exec();
        Tela_inclusao.show();
        this->show();

        if(Flag_Add_Contato)
        {
            this->Contatos_Temporarios->operator [](Contato_Auxiliar.getIdentificador()) = Contato_Auxiliar;
            this->Listar_Contatos_Tela();

            ContatoDAO DAO;
            DAO.incluir(Contato_Auxiliar);
            BIA::CategoriaContatoDAO DAO3;
            DAO3.incluir(Contato_Auxiliar);
        }
        else
        {
            throw QString("Contato não Adicionado!");
        }

    }
    catch(QString & erro){
        QMessageBox::warning(this,"OPS!",erro);
        this->show();
    }
}

void TelaPrincipal::on_tableWidget_Listagem_clicked(const QModelIndex &index)
{
    InfContatos Tela;
    int id = this->Indice_Nomde_id[ui->tableWidget_Listagem->item(index.row(),1)->text()];
    this->hide();
    Tela.SetContato(&this->Contatos_Temporarios->operator [](id),this->Contatos_Temporarios,&this->Indice_Nomde_id,&this->categorias);
    Tela.SetInformacoesTelas();
    Tela.setGeometry(this->geometry());
    Tela.exec();
    Tela.show();
    this->show();
    this->Listar_Contatos_Tela();
}

void TelaPrincipal::on_pushButton_clicked()
{
    try
    {
        CriarCategoria Tela;
        this->hide();
        Tela.setObjCategoria(&this->categorias);
        Tela.exec();
        Tela.show();
        this->show();
    }
    catch(QString & erro)
    {
        QMessageBox::warning(this,"OPS!",erro);
    }
}
