#ifndef ENDERECO_H
#define ENDERECO_H 1
#include <QString>


namespace BIA
{
  class Endereco
  {
  public:

    enum Tipo
    {
      tipo_null = 0,
      Residencial,
      Trabalho

    };  /// \enum Tipo

  private:

    unsigned int idContato;
    QString logradouro;
    int numero;
    int cep;
    QString cidade;
    QString estado;
    QString pais;
    QString complemento;
    Tipo tipo;

  public:

    Endereco ();

    Endereco (unsigned int idContato, QString logradouro, int num, int cep,
              QString cidade, QString estado, QString pais, QString complemento, Tipo tipo);

    Endereco (unsigned int idContato, QString logradouro, int num, int cep,
              QString cidade, QString estado, QString pais, QString complemento, const std::string&  tipo);

    unsigned int getIdContato () const
    { return idContato; }

    QString getLogradouro() const
    { return logradouro; }

    int getNumero() const
    { return numero; }

    int getCep() const
    { return cep; }

    QString getCidade() const
    { return cidade; }

    QString getEstado() const
    { return estado; }

    QString getPais() const
    { return pais; }

    QString getComplemento() const
    { return complemento; }

    Tipo getTipo() const
    { return tipo; }

    QString getTipoStr () const;

    void setIdContato (unsigned int id)
    { idContato = id; }

    void setLogradouro(const QString& logradouro)
    { this->logradouro = logradouro; }

    void setNumero(int numero)
    { this->numero = numero; }

    void setCep(int cep)
    { this->cep = cep; }

    void setCidade(const QString& cidade)
    { this->cidade = cidade; }

    void setEstado(const QString& estado)
    { this->estado = estado; }

    void setPais(const QString& pais)
    { this->pais = pais; }

    void setComplemento(const QString& complemento)
    { this->complemento = complemento; }

    void setTipo(const Tipo& tipo)
    { this->tipo = tipo; }

    void setTipo (const std::string &tipo);

  };  /// \class Endereco

} /// \namespace BIA

#endif // ENDERECO_H
