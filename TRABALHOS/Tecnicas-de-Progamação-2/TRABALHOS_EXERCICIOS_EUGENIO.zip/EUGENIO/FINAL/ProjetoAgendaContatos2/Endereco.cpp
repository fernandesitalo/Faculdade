#include "Endereco.h"
#include <QMessageBox>

namespace BIA
{
  Endereco::Endereco() :
    logradouro(""),
    numero(0),
    cep(0),
    cidade(""),
    estado(""),
    pais(""),
    complemento(""),
    tipo(tipo_null)
  {}

  Endereco::Endereco (unsigned int idContato, QString logradouro, int num, int cep,
                      QString cidade, QString estado, QString pais, QString complemento, Tipo tipo) :
    idContato(idContato),
    logradouro(logradouro),
    numero(num),
    cep(cep),
    cidade(cidade),
    estado(estado),
    pais(pais),
    complemento(complemento),
    tipo(tipo)
  {}

  Endereco::Endereco (unsigned int idContato, QString logradouro, int num, int cep,
                      QString cidade, QString estado, QString pais, QString complemento, const std::string&  tipo) :
    idContato(idContato),
    logradouro(logradouro),
    numero(num),
    cep(cep),
    cidade(cidade),
    estado(estado),
    pais(pais),
    complemento(complemento)
  { setTipo (tipo); }

  QString Endereco::getTipoStr () const
  {
    if (tipo == Residencial)
      return "Residencial";
    if (tipo == Trabalho)
      return "Trabalho";
    return "Sem tipo";
  }

  void Endereco::setTipo (const std::string& tipo)
  {
    if (tipo == "Residencial")
      this->tipo = Residencial;
    else
      if (tipo == "Trabalho")
        this->tipo = Trabalho;
      else
        this->tipo = tipo_null;
  }

} /// \namespace BIA
