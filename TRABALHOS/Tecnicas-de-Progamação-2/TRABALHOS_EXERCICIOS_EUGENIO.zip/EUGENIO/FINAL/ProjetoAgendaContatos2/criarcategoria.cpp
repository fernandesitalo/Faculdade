#include "criarcategoria.h"
#include "CategoriaDAO.h"
#include "ui_criarcategoria.h"

using namespace std;
CriarCategoria::CriarCategoria(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CriarCategoria)
{
    ui->setupUi(this);
}

CriarCategoria::~CriarCategoria()
{
    delete ui;
}

void CriarCategoria::on_botao_voltar_clicked()
{
    this->close();
}

void CriarCategoria::on_botao_salvar_clicked()
{
    BIA::GeradorDeId ids("idCategoria.dat");
    categ->setCategoria(ids.getNovoId(), ui->linha_categoria->text());

    CategoriaDAO DAO2;

    DAO2.incluir(ids.getId(), this->categ->getCategoria(ids.getId()));

    //BIA::CategoriaContatoDAO DAO;
    //DAO.incluir(*categ);
    /*
    for(std::map<int,BIA::Contato>::const_iterator it = Contatos_Temporarios->begin();it != this->Contatos_Temporarios->end(); ++it)
    {
        DAO3.incluir(it->second);
    }//*/

    this->close();
}
