#ifndef ADDEMAIL_H
#define ADDEMAIL_H
#include <Contato.h>
#include <QDialog>

namespace Ui {
class AddEmail;
}

class AddEmail : public QDialog
{
    Q_OBJECT

public:

    explicit AddEmail(QWidget *parent = 0);
    void setEmails(std::list<BIA::Email> * listas,int i){emails = listas,id  = i;}
    bool wasAdd(){return flagAdd;}
    ~AddEmail();

private slots:

    void on_pushButtonnok_clicked();
    void on_pushButtonok_clicked();

private:

    Ui::AddEmail * ui;
    std::list<BIA::Email> * emails;
    int id;
    int flagAdd;

};

#endif // ADDEMAIL_H
