#ifndef CONTATODAO_H
#define CONTATODAO_H
#include "crud.h"
#include <fstream>
#include <vector>

class ContatoDAO : CRUD //  CLASSE DE MANIPULAÇÃO DE ARQUIVOS
{
public:
    ContatoDAO(); /// construtor Defalt

    void incluir(BIA::Contato & obj) const; /// inclui um unico objeto Contato no Arquivo

    void incluir(std::map<int,BIA::Contato> * L) const; /// inclui, sobrescrevendo no ARQUIVO, todos contatos de uma unica vez

    std::map<int,BIA::Contato> *listar() const; /// lista todos contatos que estão no ARQUIVO

    void excluir(std::map<int,BIA::Contato> *M,int id_contato) const; /// exclui um contato do ARQUIVO
};

#endif // CONTATODAO_H
