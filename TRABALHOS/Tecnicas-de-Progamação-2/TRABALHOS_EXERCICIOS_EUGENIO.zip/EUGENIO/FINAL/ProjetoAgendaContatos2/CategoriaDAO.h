#ifndef CATEGORIADAO_H
#define CATEGORIADAO_H
#include <fstream>
#include <vector>
#include <QString>
#include <QStringList>
#include "Categoria.h"


class CategoriaDAO
{
public:
    void incluir(int id, QString descric);

    void incluirTudo (const std::map < int, QString >& __m);

    /// \return map 'alocado dinamicamente' -- lista todas categorias em um map
    std::vector<std::pair<int, QString> > *listar();
};

#endif // CATEGORIADAO_H
