#ifndef TELADEINCLUSAO_H
#define TELADEINCLUSAO_H
#include "addemail.h"
#include "addendereco.h"
#include "addtelefone.h"
#include <Contato.h>
#include <map>
#include <QDialog>
#include <GeradorDeId.h>

namespace Ui {
class telaDeInclusao;
}

class telaDeInclusao : public QDialog
{
    Q_OBJECT

public:

    explicit telaDeInclusao(QWidget *parent = 0);
    void setObjetosTelaAnterior(BIA::Contato * cto, int * flag,BIA::Categoria * obj)
    { this->cto = cto,this->flag= flag,this->categ = obj; *this->flag = 0;}
    void ListCategorias();
    ~telaDeInclusao();

private slots:

    void on_pushButtonAddTelefone_clicked();
    void on_pushButtonAddEndereco_clicked();
    void on_pushButtonAddEmail_clicked();
    void on_pushButton_Ok_clicked();
    void on_pushButton_Cancel_clicked();
    void on_comboBox_Categorias_activated(const QString &arg1);

private:


    Ui::telaDeInclusao *ui;

    BIA::GeradorDeId id;
    BIA::Contato * cto;
    BIA::Categoria * categ;

    std::list<BIA::Email> * emails;
    std::vector<BIA::Telefone> * telefones;
    std::vector<BIA::Endereco> * enderecos;
    std::vector<int> * categorias;

    int idAtual;
    int * flag;

};



#endif // TELADEINCLUSAO_H
