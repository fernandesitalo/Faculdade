#include "CategoriaContatoDAO.h"
#include "Contato.h"

void BIA::CategoriaContatoDAO::incluir ( const BIA::Contato & cto ) const
{
  std::ofstream arquivo_links("linkC.dat", std::ios_base::out | std::ios_base::app);
  if (!arquivo_links.is_open())
    throw QString("CategoriaContatoDAO: incluir: não pôde abrir arquivo");

  std::vector<int> const * categoria = cto.getCategorias();
  for(int i = 0;i<(int)categoria->size();i++)
  {
      arquivo_links << cto.getIdentificador() << " " << categoria->at(i) << '\n';
  }
}

std::vector<std::pair<int, int> > *BIA::CategoriaContatoDAO::listar() const
{
  std::fstream arquivo_links("linkC.dat",std::ios::in|std::ios::app);
  if (!arquivo_links.is_open())
    throw QString("CategoriaContatoDAO: listar: não pôde abrir arquivo");

  std::pair < int, int > link;
  std::vector < std::pair < int, int > >* mapa_links = new std::vector < std::pair < int, int > >;

  while (arquivo_links >> link.first >> link.second)
  {// pega todos os dados

      mapa_links->push_back(link);                                        // insere no vector
      //cout<<link.first<<link.second<<endl;

  }

  return mapa_links;
}

void BIA::CategoriaContatoDAO::exluir(int id_contato) const
{
    std::vector<std::pair<int,int> >*V = listar();
    std::ofstream arquivo_links("linkC.dat", std::ios_base::out);
      if (!arquivo_links.is_open())
        throw QString("CategoriaContatoDAO: incluir: não pôde abrir arquivo");


      for(std::vector<std::pair<int,int> >::iterator it = V->begin() ; it != V->end() ; ++it ){
          if(it->first != id_contato){
             arquivo_links << it->first << " " << it->second << '\n';
          }
      }
    delete V;
}
