#ifndef EMAIL_H
#define EMAIL_H
#include <QString>


namespace BIA
{
class Email
{
private:

    unsigned int idContato;
    QString email;

public:

    Email() :
      idContato(0),
      email("")
    {}

    Email(unsigned int idContato, QString email) :
      idContato(idContato),
      email(email)
    {}

    unsigned int getIdContato () const
    { return idContato; }

    QString getEmail () const
    { return email; }

    void setIdContato (unsigned int id)
    { idContato = id; }

    void setEmail (QString email)
    { this->email = email; }

    bool operator == (Email A)
    { return (this->getIdContato() == A.getIdContato() && this->getEmail() == A.getEmail()); }

};  /// \class Email

} /// \namespace BIA

#endif // EMAIL_H
