#ifndef TELAPRINCIPAL_H
#define TELAPRINCIPAL_H
#include "teladeinclusao.h"
#include "Contato.h"
#include "Email.h"
#include "Endereco.h"
#include "Telefone.h"
#include <QMainWindow>
#include <QMessageBox>
#include <map>
#include <QString>
#include <QModelIndex>
#include <vector>

namespace Ui
{
  class TelaPrincipal;
}

class TelaPrincipal :
    public QMainWindow
{
  Q_OBJECT

public:
  explicit TelaPrincipal(QWidget *parent = 0);
  ~TelaPrincipal();
   void Listar_Contatos_Tela();

private slots:
  void on_pushButton_IncluirContato_clicked();
  void on_tableWidget_Listagem_clicked(const QModelIndex &index);
  void on_pushButton_clicked();

private:
  Ui::TelaPrincipal *ui;
  std::map<int,BIA::Contato> *Contatos_Temporarios;
  std::map<QString,int> Indice_Nomde_id;
  BIA::Categoria categorias;

};

#endif // TELAPRINCIPAL_H

