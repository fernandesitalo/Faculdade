#include "Contato.h"

namespace BIA
{
  Contato::Contato () :
    identificador(0),
    nomeCompleto("")
  {}

  Contato::Contato (unsigned int identificador, QString nomeCompleto, std::list<Email> &emails, std::vector<Endereco> &enderecos, std::vector<Telefone> &telefones) :
    identificador(identificador),
    nomeCompleto(nomeCompleto),
    emails(emails),
    enderecos(enderecos),
    telefones(telefones)
  {}

} /// \namespace BIA
