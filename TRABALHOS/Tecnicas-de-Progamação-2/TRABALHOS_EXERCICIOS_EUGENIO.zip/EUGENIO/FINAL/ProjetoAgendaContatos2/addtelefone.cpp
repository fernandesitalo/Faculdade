#include "addtelefone.h"
#include "ui_addtelefone.h"
#include <QMessageBox>

AddTelefone::AddTelefone(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AddTelefone)
{
    flagAdd = 0;
    ui->setupUi(this);
}

AddTelefone::~AddTelefone()
{
    delete ui;
}

void AddTelefone::on_pushButtonCancel_clicked()
{
    this->close();
}

void AddTelefone::on_pushButton_OK_clicked()
{
    try{

        BIA::Telefone aux;
        QString numeros;

        numeros = ui->lineEditDDi->text();
        if(numeros.isEmpty())
            throw QString("DDI inválido");

        aux.setDDI(numeros.toInt());

        numeros = ui->lineEditDDD->text();
        if(numeros.isEmpty())
            throw QString("DDD inválido");
        aux.setDDD(numeros.toInt());

        numeros = ui->lineEditNumero->text();
        if(numeros.isEmpty())
            throw QString("Numero inválido");
        aux.setNumero(numeros.toLongLong());

        aux.setIdContato(id);

        telefones->push_back(aux);
        flagAdd =true;
        this->close();

    }catch(QString & erro){
        flagAdd = false;
        QMessageBox::warning(this,"",erro);
    }
}
