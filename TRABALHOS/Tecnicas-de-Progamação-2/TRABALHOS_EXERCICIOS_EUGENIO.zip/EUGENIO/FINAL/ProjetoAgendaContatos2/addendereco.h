#ifndef ADDENDERECO_H
#define ADDENDERECO_H
#include <Endereco.h>
#include <QDialog>

namespace Ui {
class AddEndereco;
}

class AddEndereco : public QDialog
{

    Q_OBJECT

public:

    explicit AddEndereco(QWidget *parent = 0);
    void setEnderecoVector(std::vector<BIA::Endereco> * t,int i){ enderecos = t,id  = i;}
    bool wasAdd(){return flagAdd;}
    ~AddEndereco();

private slots:

    void on_pushButton_clicked();

    void on_pushButtonCance_clicked();

private:

    Ui::AddEndereco *ui;
    std::vector<BIA::Endereco> * enderecos;
    int id;
    bool flagAdd;

};

#endif // ADDENDERECO_H
