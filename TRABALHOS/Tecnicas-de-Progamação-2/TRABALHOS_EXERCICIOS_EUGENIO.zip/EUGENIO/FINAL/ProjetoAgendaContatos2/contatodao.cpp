#include "contatodao.h"
#include "Email.h"
#include "Endereco.h"
#include <map>
#include <QStringList>
#include <qstringlist.h>
#include "CategoriaContatoDAO.h"

ContatoDAO::ContatoDAO()
{}

void ContatoDAO::incluir(BIA::Contato &obj) const
{
    std::ofstream arqContatos;
    std::ofstream arqTelefones;
    std::ofstream arqEnderecos;
    std::ofstream arqEmail;

    arqContatos.open("Contatos.txt",std::ios::out|std::ios::app);
    arqTelefones.open("Telefones.txt",std::ios::out|std::ios::app);
    arqEmail.open("Email.txt",std::ios::out|std::ios::app);
    arqEnderecos.open("Enderecos.txt",std::ios::out|std::ios::app);

    if(!arqContatos.is_open())
        throw QString("Arquivo de contatos nao foi aberto - Metodo incluir");

    if(!arqTelefones.is_open())
    {
        arqContatos.close();
        throw QString("Arquivo de telefones nao foi aberto - Metodo incluir");
    }

    if(!arqEmail.is_open())
    {
        arqContatos.close();
        arqTelefones.close();
        throw QString("Arquivo de Email nao foi aberto - Metodo incluir");
    }

    if(!arqEnderecos.is_open())
    {
        arqContatos.close();
        arqTelefones.close();
        arqEmail.close();
        throw QString("Arquivo de Endereços nao foi aberto - Metodo incluir");
    }

    /// Gravar nome e id do contato no ARQUIVO DE NOME-ID
    QString stg;
    stg = QString::number(obj.getIdentificador()) + ";" + obj.getNomeCompleto();
    arqContatos << stg.toStdString() << '\n';
    arqContatos.close(); // fecha fluxo aberto


    /// Gravar Telefones do contato no ARQUIVO DE TELEFONE
    std::vector<BIA::Telefone> const * const numerosT = obj.getTelefone();
    BIA::Telefone aux2;
    for(int i =0 ; i <(int)numerosT->size();i++)
    {
        aux2 = numerosT->at(i);
        stg = QString::number(aux2.getIdContato()) + ";"
                + QString::number(aux2.getDDI()) + ";"
                + QString::number(aux2.getDDD()) + ";"
                + QString::number(aux2.getNumero()) + ";"
                + aux2.getTipoStr() + "\n";

        arqTelefones << stg.toStdString();
    }
    arqTelefones.close(); // fecha fluxo aberto


    /// Gravar Email no ARQUIVO DE EMAILS
    std::list<BIA::Email> const * const emails = obj.getEmail();
    if(emails!=NULL)
    {
        BIA::Email aux3;
        for(std::list<BIA::Email>::const_iterator it = emails->begin(); it != emails->end(); ++it)
        {
            aux3 = *it;
            arqEmail << QString::number(aux3.getIdContato()).toStdString() + ";" + aux3.getEmail().toStdString() + "\n";
        }
    }
    arqEmail.close(); // fecha fluxo aberto


    /// Gravar Endereços no ARQUIVO DE ENDEREÇOS
    std::vector<BIA::Endereco> const * const enderecos = obj.getEndereco();
    BIA::Endereco aux4;
    if(enderecos != NULL)
    {
        for (register uint i = 0; i < enderecos->size(); ++i)
        {
            aux4 = enderecos->at(i);

            stg = QString::number(aux4.getIdContato()) + ";" +
                    aux4.getLogradouro() + ";" +
                    QString::number(aux4.getNumero()) + ";" +
                    QString::number(aux4.getCep()) + ";" +
                    aux4.getCidade() +";"+ aux4.getEstado() + ";" +
                    aux4.getPais() + ";" + aux4.getComplemento() + ";" +
                    aux4.getTipoStr() + "\n";

            arqEnderecos << stg.toStdString();
        }
    }
    arqEnderecos.close(); // fecha fluxo aberto
}

void ContatoDAO::incluir(std::map<int, BIA::Contato> *L) const
{
    // abertura dos fluxos/arquivos
    std::ofstream arqContatos;
    std::ofstream arqTelefones;
    std::ofstream arqEnderecos;
    std::ofstream arqEmail;
    ///_______________________ VALIDAÇÃO DA ABERTURA_________________________
    arqContatos.open("Contatos.txt",std::ios::out);
    if(!arqContatos.is_open())
        throw QString("Arquivo de contatos nao foi aberto - Metodo incluir");

    arqTelefones.open("Telefones.txt",std::ios::out);
    if(!arqTelefones.is_open())
    {
        arqContatos.close();
        throw QString("Arquivo de telefones nao foi aberto - Metodo incluir");
    }

    arqEmail.open("Email.txt",std::ios::out);
    if(!arqEmail.is_open())
    {
        arqContatos.close();
        arqTelefones.close();
        throw QString("Arquivo de Email nao foi aberto - Metodo incluir");
    }

    arqEnderecos.open("Enderecos.txt",std::ios::out);
    if(!arqEnderecos.is_open())
    {
        arqContatos.close();
        arqTelefones.close();
        arqEmail.close();
        throw QString("Arquivo de Endereços nao foi aberto - Metodo incluir");
    }

    QString stg;
    BIA::Contato obj;

    for(std::map<int,BIA::Contato>::iterator it = L->begin();it!= L->end();++it){
        obj = it->second;

        /// GRAVAR NOMES E ID DO OBJ
        stg = QString::number( obj.getIdentificador() ) + ";" + obj.getNomeCompleto();
        arqContatos << stg.toStdString() << '\n';

        /// GRAVAR TELEFONES DO OBJ
        std::vector< BIA::Telefone > const * const numerosT = obj.getTelefone();
        BIA::Telefone aux2;
        for(int t = 0 ; t < (int) numerosT->size(); ++t )
        {
            QString str_t;
            aux2 = numerosT->at(t);
            str_t = QString::number( aux2.getIdContato() ) + ";"
                    + QString::number(aux2.getDDI()) + ";"
                    + QString::number(aux2.getDDD()) + ";"
                    + QString::number(aux2.getNumero()) + ";"
                    + aux2.getTipoStr() + "\n";
            arqTelefones << str_t.toStdString();
        }

        /// GRAVAR EMAIL DO OBJ
        std::list<BIA::Email> const * const emails = obj.getEmail();
        if(emails != NULL)
        {
            BIA::Email aux3;
            for(std::list<BIA::Email>::const_iterator it = emails->begin() ; it != emails->end() ; ++it)
            {
                aux3 = *it;
                arqEmail << QString::number(aux3.getIdContato()).toStdString() + ";" + aux3.getEmail().toStdString() + "\n";
            }
        }

        /// GRAVAR ENDEREÇOS DO OBJ
        std::vector<BIA::Endereco> const * const enderecos = obj.getEndereco();
        BIA::Endereco aux4;
        if(enderecos != NULL)
        {
            for (int u = 0; u < (int)enderecos->size(); ++u )
            {
                aux4 = enderecos->at(u);

                stg = QString::number( aux4.getIdContato() ) + ";" +
                        aux4.getLogradouro() + ";" +
                        QString::number( aux4.getNumero() ) + ";" +
                        QString::number( aux4.getCep() ) + ";" +
                        aux4.getCidade() + ";" + aux4.getEstado() + ";" +
                        aux4.getPais() + ";" + aux4.getComplemento() + ";" +
                        aux4.getTipoStr() + "\n";
                arqEnderecos << stg.toStdString();
            }
        }
    }
    // fecha todos fluxos abertos
    arqEnderecos.close();
    arqEmail.close();
    arqContatos.close();
    arqTelefones.close();
}




std::map<int, BIA::Contato> *ContatoDAO::listar() const   /// *I
{
    // abertura dos fluxos
    std::fstream arqContatos;
    std::fstream arqTelefones;
    std::fstream arqEnderecos;
    std::fstream arqEmail;

    /// Abertura dos arquivos para leitura e verificação de abertura
    arqContatos.open("Contatos.txt",std::ios::in|std::ios::app);
    if(!arqContatos.is_open())
        throw QString("Arquivo de contatos nao foi aberto - Metodo Listar");

    arqTelefones.open("Telefones.txt",std::ios::in|std::ios::app);
    if(!arqTelefones.is_open())
    {
        arqContatos.close();
        throw QString("Arquivo de telefones nao foi aberto - Metodo Listar");
    }

    arqEmail.open("Email.txt",std::ios::in|std::ios::app);
    if(!arqEmail.is_open())
    {
        arqContatos.close();
        arqTelefones.close();
        throw QString("Arquivo de Email nao foi aberto - Metodo Listar");
    }

    arqEnderecos.open("Enderecos.txt",std::ios::in|std::ios::app);
    if(!arqEnderecos.is_open())
    {
        arqContatos.close();
        arqTelefones.close();
        arqEmail.close();
        throw QString("Arquivo de Endereços nao foi aberto - Metodo Listar");
    }

    // criar o map <identificador, objeto contato >
    std::map<int,BIA::Contato>* ptMap = new std::map<int,BIA::Contato>();

    if(ptMap == NULL) /// pode ser que já seja lançada uma execessão BAD_ALLOC
    {
        throw QString("Erro Ao alocar memoria!");
    }

    /// primeiro arquivo... arqContatos , possui : id_Identificador ; Nome Completo

    std::string linha;

    //____________________________________ VARRER ARQUIVO CONTATOS____________________________________//
    std::getline(arqContatos,linha);
    while(!arqContatos.eof())
    {
        QString str = QString::fromStdString(linha);

        QStringList camps = str.split(";");
        if(camps.length() != 2){
            throw QString ("LEITURA DO Arquivo DE CONTATOS Errado, Jogue o Progama Fora!");
        }

        ptMap->operator [](camps[0].toInt()).setIdentificador(camps[0].toInt());
        ptMap->operator []( camps[0].toInt() ).setNomeCompleto( camps[1] );
        std::getline(arqContatos,linha);
    }
    arqContatos.close(); // foi varido o primeiro arquivo e setato tudo no ponteiro

    //____________________________________ VARRER ARQUIVO TELEFONES ___________________________________//
    std::getline(arqTelefones,linha);
    while(!arqTelefones.eof())
    {
        QString str = QString::fromStdString(linha);
        QStringList camps = str.split(";");
        if(camps.length() != 5){
            throw QString ("LEITURA DO Arquivo DE TELEFONES Errado, Jogue o Progama Fora!");
        }
        BIA::Telefone T;
        T.setIdContato(camps[0].toInt());
        T.setDDD(camps[1].toInt());
        T.setDDI(camps[2].toInt());
        T.setNumero(camps[3].toInt());
        T.setTipo(camps[4]);
        ptMap->operator [](camps[0].toInt()).adicionaTelefone(T);
        std::getline(arqTelefones,linha);
    }
    arqTelefones.close();


    //______________________________________VARRER ARQUVO DE EMAIS________________________________________//
    std::getline(arqEmail,linha);
    while(!arqEmail.eof()){
        QString str = QString::fromStdString(linha);
        QStringList camps = str.split(";");
        if(camps.length() != 2){
            throw QString ("LEITURA DO Arquivo EMAIL Errado, Jogue o Progama Fora!");
        }
        BIA::Email E;
        E.setIdContato(camps[0].toInt());
        E.setEmail(camps[1]);
        ptMap->operator [](camps[0].toInt()).adicionaEmail(E);
        std::getline(arqEmail,linha);
    }
    arqEmail.close();


    //_______________________________________VARRER ARQUIVO DE ENDEREÇOS__________________________________//
    std::getline(arqEnderecos,linha);
    while( !arqEnderecos.eof() ){
        QString str = QString::fromStdString( linha );
        QStringList camps = str.split(";");
        if(camps.length() != 9)
            throw QString ("LEITURA DO Arquivo Errado ENDERECOS , Jogue o Progama Fora!");

        BIA::Endereco E;
        E.setIdContato(camps[0].toInt());
        E.setLogradouro(camps[1]);
        E.setNumero(camps[2].toInt());
        E.setCep(camps[3].toInt());
        E.setCidade(camps[4]);
        E.setEstado(camps[5]);
        E.setPais(camps[6]);
        E.setComplemento(camps[7]);
        E.setTipo(camps[8].toStdString());

        ptMap->operator []( camps[0].toInt() ).adicionaEndereco( E );
        std::getline(arqEnderecos,linha);
    }
    arqEnderecos.close();
    return ptMap;
}

void ContatoDAO::excluir(std::map<int,BIA::Contato> *M,int id_contato) const
{
    M->erase(M->find( id_contato ));
    incluir(M);
    BIA::CategoriaContatoDAO DAO;
    DAO.exluir( id_contato );
}
