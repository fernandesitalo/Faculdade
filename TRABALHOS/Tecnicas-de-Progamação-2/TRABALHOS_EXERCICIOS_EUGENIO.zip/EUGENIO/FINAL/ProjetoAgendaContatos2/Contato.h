#ifndef CONTATO_HPP
#define CONTATO_HPP 1
#include "Email.h"
#include "Endereco.h"
#include "Telefone.h"
#include "Categoria.h"
#include <QString>
#include <list>
#include <vector>

namespace BIA
{
  class Contato
  {
    unsigned int             identificador;
    QString                  nomeCompleto;
    std::list < Email >      emails;
    std::vector < Endereco > enderecos;
    std::vector < Telefone > telefones;
    std::vector <int>        Categorias;

  public:

    /// constroi com valores padrão
    Contato();

    /// constroi com vários dados
    Contato (unsigned int identificador, QString nomeCompleto, std::list < Email >& emails,
             std::vector<Endereco> &enderecos, std::vector<Telefone> &telefones);

    /// \return o identificador do contato
    unsigned int getIdentificador () const
    { return identificador; }

    /// \return nome do contato
    QString getNomeCompleto () const
    { return nomeCompleto; }

    /// \return referencia para emails
    const std::list < Email >* getEmail () const
    { return &emails; }

    /// \return referencia para enderecos
    const std::vector < Endereco >* getEndereco () const
    { return &enderecos; }

    /// \return referencia para telefones
    const std::vector < Telefone >* getTelefone () const
    { return &telefones; }

    /// \return todas categorias que o contato pertence!
    const std::vector < int > * getCategorias () const
    { return &this->Categorias; }

    /// seta o identificador do contato
    void setIdentificador (unsigned int identificador)
    { this->identificador = identificador; }

    /// seta o nome do contato
    void setNomeCompleto (QString nomeCompleto)
    { this->nomeCompleto = nomeCompleto; }

    /// seta uma lista de emails do contato
    void setEmails (std::list < Email >& emails)
    { this->emails = emails; }

    /// seta uma lista de enderecos do contato
    void setEnderecos (std::vector < Endereco >& enderecos)
    { this->enderecos = enderecos; }

    /// seta vários telefones
    void setTelefones (std::vector < Telefone >& telefones)
    { this->telefones = telefones; }

    /// seta todas categorias que o conntato pertence
    void SetCategorias (std::vector <int> & categorias)
    { this->Categorias = categorias; }

    /// seta categorias pelo id da categoria
    void SetCategoria (int categoria)
    { this->Categorias.push_back(categoria); }



    /// adiciona um email
    void adicionaEmail (const Email& email)
    { emails.push_back(email); }

    /// adiciona um endereco
    void adicionaEndereco (const Endereco& endereco)
    { enderecos.push_back(endereco); }

    /// adiciona um telefone
    void adicionaTelefone (const Telefone& telefone)
    { telefones.push_back(telefone); }

  };  /// \class Contato

} /// \namespace BIA

#endif // CONTATO_H
