#include "addendereco.h"
#include "ui_addendereco.h"
#include <qmessagebox.h>

AddEndereco::AddEndereco(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AddEndereco)
{
    ui->setupUi(this);
}

AddEndereco::~AddEndereco()
{
    delete ui;
}

void AddEndereco::on_pushButton_clicked()
{
    try{

        BIA::Endereco aux;
        QString  str;

        str = ui->lineEditCep->text();
        if(str.isEmpty()) throw QString("CEP Invalido");
        aux.setCep(str.toInt());

        str = ui->lineEditPais->text();
        if(str.isEmpty()) throw QString("País Invalido");
        aux.setPais(str);

        str = ui->lineEditCidade->text();
        if(str.isEmpty()) throw QString("Cidade Invalido");
        aux.setCidade(str);

        str = ui->lineEditComplemento->text();
        if(str.isEmpty()) throw QString("complemento Invalido");
        aux.setComplemento(str);

        str = ui->lineEditEstado->text();
        if(str.isEmpty()) throw QString("Estado Invalido");
        aux.setEstado(str);

        str = ui->lineEditLogradouro->text();
        if(str.isEmpty()) throw QString("Logradouro Invalido");
        aux.setLogradouro(str);

        str = ui->lineEditNumero->text();
        if(str.isEmpty()) throw QString("Numero Invalido");
        aux.setNumero(str.toInt());

        int nt = ui->comboBoxTipo->currentIndex();
        if(nt ==  1)
            aux.setTipo("Residencial");
        else
            aux.setTipo("Trabalho");

        aux.setIdContato(id);
        this->enderecos->push_back(aux);
        flagAdd = true;
        this->close();

    }catch(QString  & erro){
        flagAdd = false;
        QMessageBox::warning(this," ",erro);
    }
}

void AddEndereco::on_pushButtonCance_clicked()
{
    this->close();
}
