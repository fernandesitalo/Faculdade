#include "teladeinclusao.h"
#include "ui_teladeinclusao.h"
#include "contatodao.h"
#include <QMessageBox>


telaDeInclusao::telaDeInclusao(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::telaDeInclusao),
    id("id.dat")
{
    idAtual = id.getNovoId();
    emails = new std::list<BIA::Email>;
    enderecos = new std::vector<BIA::Endereco>;
    telefones = new std::vector<BIA::Telefone>;
    categorias = new std::vector<int>;

    ui->setupUi(this);
}

void telaDeInclusao::ListCategorias()
{
     std::map<int,QString> const * aux = categ->getAll();
     for(std::map<int,QString>::const_iterator it = aux->begin();it!=aux->end();it++)
     {
         ui->comboBox_Categorias->insertItem(0,it->second);
     }

}

telaDeInclusao::~telaDeInclusao()
{
    if (!*flag)
        this->id.removeId();
    delete emails;
    delete enderecos;
    delete telefones;
    delete categorias;
    delete ui;
}

void telaDeInclusao::on_pushButtonAddTelefone_clicked()
{
    try{

        BIA::Telefone telefone;
        AddTelefone tela;

        tela.setTelefones(telefones,idAtual);
        tela.exec();
        tela.show();

        if(!tela.wasAdd())
          throw QString("Telefone nao adicionado");

        telefone = telefones->back();
        QString aux = QString::number(telefone.getDDI()) + "-" + QString::number(telefone.getDDD())
                                                      + "-" + QString::number(telefone.getNumero());
        ui->listWidget_Telefone->insertItem(0,aux);

    }catch(QString & erro){
        QMessageBox::warning(this,"",erro);
    }
}

void telaDeInclusao::on_pushButtonAddEndereco_clicked()
{
    try{

        BIA::Endereco endereco;
        AddEndereco tela;

        tela.setEnderecoVector(enderecos,idAtual);
        tela.exec();
        tela.show();

        if(!tela.wasAdd())
          throw QString("Endereço nao adicionado");

        endereco = enderecos->back();

        QString aux = QString::number(endereco.getCep())+ "-" +
                endereco.getLogradouro() + "-" + endereco.getCidade() + "-" +
                      endereco.getEstado() + "-" + endereco.getPais() + "-" +
                                                       endereco.getTipoStr();
        ui->listWidget_Endereco->insertItem(0,aux);

    }catch(QString & erro){
        QMessageBox::warning(this,"",erro);
    }
}

void telaDeInclusao::on_pushButtonAddEmail_clicked()
{
    try{

        BIA::Email email;
        AddEmail tela;

        tela.setEmails(emails,idAtual);
        tela.exec();
        tela.show();

        if(!tela.wasAdd())
          throw QString("Email nao adicionado");

        email = emails->back();

        QString aux = email.getEmail();

        ui->listWidget_Email->insertItem(0,aux);

    }catch(QString & erro){
        QMessageBox::warning(this,"",erro);
    }
}


void telaDeInclusao::on_pushButton_Ok_clicked()
{
    try{

        if(ui->lineEditNome->text().isEmpty())
          throw QString("Nome necessario para a criaçao do contato");
        if(telefones->empty())
          throw QString("Telefone Necessario para a criaçao do contato");
        if (this->emails->empty())
          throw QString("e-mail necessário para a criaçao do contato");
        if (this->enderecos->empty())
          throw QString("endereco necessario para a criaçao do contato");


        QString nome = ui->lineEditNome->text();
        for (int i = 0; i < nome.length(); ++i)
            nome[i] = toupper(nome[i].toLatin1());

        cto->setNomeCompleto(nome);
        cto->setEmails(*emails);
        cto->setEnderecos(*enderecos);
        cto->setTelefones(*telefones);
        cto->setIdentificador(idAtual);
        cto->SetCategorias(*categorias);
       *flag = 1;

        this->close();

    }catch(QString & erro){
        QMessageBox::warning(this,"",erro);
    }
}

void telaDeInclusao::on_pushButton_Cancel_clicked()
{
   *flag = 0;
    //this->id.removeId();
    this->close();
}

void telaDeInclusao::on_comboBox_Categorias_activated(const QString &arg1)
{
    if(arg1 == "Nenhuma")
        return;
    try
    {
       this->categorias->push_back( this->categ->buscaId(arg1) );
       ui->listWidget_Categorias->insertItem(0,arg1);

    }catch(...)
    {

    }
}
