#ifndef CATEGORIACONTATO_H
#define CATEGORIACONTATO_H
#include <vector>

namespace BIA
{
  class CategoriaContato
  {
    std::vector < std::pair < int, int > > linkagem;

  public:

    /// adiciona um link
    void setLink (int idContato, int idCategoria)
    { linkagem.push_back(std::make_pair( idContato, idCategoria )); }

    /// \return link na posição \p pos
    std::pair < int, int > getLink (int pos)
    { return linkagem.at(pos); }

    /// \return ponteiro para todos os links
    const std::vector < std::pair < int, int > >* getAll () const
    { return &linkagem; }

  };  /// \class CategoriaContato

} /// \namespace BIA

#endif // CATEGORIACONTATO_H
