#include "CategoriaDAO.h"

void CategoriaDAO::incluir(int id, QString descric)
{
    std::ofstream arquivo_categorias("categorias.dat", std::ios_base::app);
    if (!arquivo_categorias.is_open())
        throw QString("CategoriaDAO::incluir: Arquivo nao pode ser aberto");
    arquivo_categorias << id << ";"<<descric.toStdString()<<"\n";
}

void CategoriaDAO::incluirTudo(const std::map<int, QString>& __m)
{
    std::ofstream arquivo_categorias("categorias.dat");
    if (!arquivo_categorias.is_open())
        throw QString("CategoriaDAO::incluirTudo: Arquivo nao pode ser aberto");

    for(std::map<int,QString>::const_iterator it = __m.begin(); it != __m.end(); ++it)
    {
        arquivo_categorias << it->first << ";" << it->second.toStdString() << "\n";
    }
}

std::vector < std::pair<int,QString> > *CategoriaDAO::listar()
{
    std::vector < std::pair<int,QString> >* vetor = new std::vector < std::pair<int,QString> >;
    std::fstream arquivo_categorias("categorias.dat");

    if (arquivo_categorias.is_open())
    {
        std::string linha;
        std::getline(arquivo_categorias,linha);
        while (!arquivo_categorias.eof())
        {
            QString qstr = QString::fromStdString(linha);
            QStringList qstrl = qstr.split(';');

            if (qstrl.size() != 2)
            {
                throw QString("CategoriaDAO::listar: erro de logica");
            }
            std::pair<int,QString> aux(qstrl[0].toInt(),qstrl[1]);
            vetor->push_back(aux);
            std::getline(arquivo_categorias,linha);
        }
    }

    return vetor;
}
