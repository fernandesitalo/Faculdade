#include "addemail.h"
#include "ui_addemail.h"
#include <QMessageBox>

AddEmail::AddEmail(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AddEmail)
{
    flagAdd = 0;
    ui->setupUi(this);
}

AddEmail::~AddEmail()
{
    delete ui;
}

void AddEmail::on_pushButtonnok_clicked()
{
    flagAdd  = false;
    this->close();
}

void AddEmail::on_pushButtonok_clicked()
{
    try{
        BIA::Email objEmail;
        QString aux ;
        aux = ui->lineEditEmail->text();
        if(aux.isEmpty())
            throw QString("Email Invalido");
        objEmail.setEmail(aux);
        objEmail.setIdContato(id);
        this->emails->push_back(objEmail);
        flagAdd = true;
        this->close();
    }catch(QString & erro){
        flagAdd = false;
        QMessageBox::warning(this,"d ",erro);
    }
}
