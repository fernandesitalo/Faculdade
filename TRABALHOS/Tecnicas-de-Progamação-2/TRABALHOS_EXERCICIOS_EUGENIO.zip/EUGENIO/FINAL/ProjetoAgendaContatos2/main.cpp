#include "telaprincipal.h"
#include <QApplication>

int main(int argc, char *argv[])
{
  QApplication a(argc, argv);
  TelaPrincipal w;
  w.show();
  return a.exec();
}


/*
                                  :: ESCOPO DE IDEIAS ::

    ::::::::Tela de Listagem

    funcao listar() -> contatodao -> retorna uma estrutura de dados com todos objetos

    1 - obj contato (inicializar atributos)
    2 - varrer arquivo para pegar respectivos dados com o id do contato em questao
    ( Telefones em pilha /  Endereço em fila / Emails em vector ) // exemplo


    solucao "BOA":
        -> lista de contatos ordenados pelo ID
        -> lista de telefones/Endereços/Emails ordenados pelo ID

   ///----------------------------------------------------------
   USAR UM MAP PARA ENDERECO, UM PARA EMAIL, UM PARA TELEFONE

   MAP<INT,CONTATO> LISTADECONTATOS;
   INT - ID
   CONTATO - O OBJETO EM SI

   ->   desta maneira abrimos os arquivos uma unica vez
   ->   melhor que qualquer lista, alem de deixar ordenado!
   ->   tempo linear gasto, uma iteracao entre cada arquivo!
   ///----------------------------------------------------------



   incluir -> (obj) / (map)   --- [incluir sera o alterar na tablewidget, opcoes ao clicar com o botao direito... ALTERAR E EXLUIR]
   listar-> ok
   exluir -> seta tudo na tabela, se excluir da tabela,exluir do map, que e passado como parametro para o metodo de incluir sobrecarregado
*/
