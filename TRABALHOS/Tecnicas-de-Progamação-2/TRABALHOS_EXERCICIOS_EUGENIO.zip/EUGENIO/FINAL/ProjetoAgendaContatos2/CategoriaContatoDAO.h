#ifndef CATEGORIACONTATODAO_H
#define CATEGORIACONTATODAO_H
#include "Contato.h"
#include <fstream>
#include <vector>
#include <QString>
#include <vector>
#include "CategoriaContato.h"


namespace BIA
{
  class CategoriaContatoDAO
  {

  public:

    /// inclui um link
    void incluir (const Contato &cto) const;
    /// \return um vector 'alocado dinâmicamente' --- listagem dos links
    std::vector < std::pair < int, int >  >* listar () const;

    void exluir(int id_contato) const;

  };  /// \class CategoriaContatoDAO

} /// \namespace BIA

#endif // CATEGORIACONTATODAO_H
