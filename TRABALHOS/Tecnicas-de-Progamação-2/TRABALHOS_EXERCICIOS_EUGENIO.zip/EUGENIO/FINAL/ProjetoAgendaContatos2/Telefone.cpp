#include "Telefone.h"

namespace BIA
{
  Telefone::Telefone() :
    idContato(0),
    DDI(0),
    DDD(0),
    numero(0),
    tipo(tipo_null)
  {}

  Telefone::Telefone (unsigned int idContato, unsigned int DDI, unsigned int DDD, unsigned int numero, Tipo tipo) :
    idContato(idContato),
    DDI(DDI),
    DDD(DDD),
    numero(numero),
    tipo(tipo)
  {}

  Telefone::Telefone (unsigned int idContato, unsigned int DDI, unsigned int DDD, unsigned int numero, QString tipo) :
    idContato(idContato),
    DDI(DDI),
    DDD(DDD),
    numero(numero)
  { setTipo(tipo); }

  QString Telefone::getTipoStr () const
  {
    if (tipo == tipo_null)
      return "Sem tipo";
    if (tipo == Comercial)
      return "Comercial";
    if (tipo == Residencial)
      return "Residencial";
    return "Trabalho";
  }

  void Telefone::setTipo (QString tipo)
  {
    if (tipo == "Comercial")
      this->tipo = Comercial;
    if (tipo == "Residencial")
      this->tipo = Residencial;
    if (tipo == "Trabalho")
      this->tipo = Trabalho;
    this->tipo = tipo_null;
  }

} /// \namespace BIA
