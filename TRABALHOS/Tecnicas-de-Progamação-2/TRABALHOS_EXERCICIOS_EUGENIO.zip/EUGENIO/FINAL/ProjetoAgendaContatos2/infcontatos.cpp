#include "infcontatos.h"
#include "ui_infcontatos.h"
#include "contatodao.h"

InfContatos::InfContatos(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::InfContatos)
{
    ui->setupUi(this);
}

void InfContatos::SetInformacoesTelas()
{
    QString stg;
    std::vector<BIA::Telefone> const * end = CTO->getTelefone();
    for(int i = 0;i<(int)end->size();++i)
    {
        stg = "+" + QString::number(end->at(i).getDDI()) + " ("
                +QString::number(end->at(i).getDDD())+ ") " + " "
                + QString::number(end->at(i).getNumero());
        ui->listWidget_Telefone->insertItem(0,stg);
    }

    std::vector<BIA::Endereco> const * Enderecos = CTO->getEndereco();
    for(int i = 0; i < (int)Enderecos->size();i++)
    {
        BIA::Endereco aux = Enderecos->at(i);
        stg =   aux.getLogradouro() + " - " +
                QString::number(aux.getNumero()) + " - " +
                QString::number(aux.getCep()) + " - " +
                aux.getCidade() +" - "+ aux.getEstado() + " - " +
                aux.getPais() + " - " + aux.getComplemento() + " - " +
                aux.getTipoStr();
        ui->listWidget_Endereco->insertItem(0,stg);
    }

    std::list<BIA::Email> const *  emails = CTO->getEmail();
    for(std::list<BIA::Email>::const_iterator it = emails->begin(); it != emails->end(); ++it)
    {
      BIA::Email aux = *it;
      ui->listWidget_Email->insertItem(0,aux.getEmail());
    }
    ui->lineEditNome->setText(CTO->getNomeCompleto());

    std::vector<int> const * categoria= this->CTO->getCategorias();
    for(int i = 0;i<(int)categoria->size();i++)
    {
        ui->listWidget_4->insertItem(0,categ->getCategoria(categoria->at(i)));
    }
}

InfContatos::~InfContatos()
{
    delete ui;
}

void InfContatos::on_pushButton_DeletarContato_clicked()
{
    /*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
    if (QMessageBox::question(this, "Deletar", "Tem certeza?", QMessageBox::Yes|QMessageBox::No) == QMessageBox::Yes)
    {
        ContatoDAO arq;
        arq.excluir(contatos,indice->at(ui->lineEditNome->text()));
        this->close();
    }
}

void InfContatos::on_pushButton_Sair_clicked()
{
    this->close();
}
