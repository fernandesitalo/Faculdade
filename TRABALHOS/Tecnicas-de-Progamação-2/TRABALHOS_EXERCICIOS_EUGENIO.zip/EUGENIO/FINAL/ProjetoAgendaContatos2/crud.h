#ifndef CRUD_H
#define CRUD_H
#include <queue>
#include <map>
#include "Contato.h"

class CRUD
{
public:
    virtual void incluir(BIA::Contato & obj) const = 0;
    virtual void incluir(std::map<int,BIA::Contato> * L) const = 0;
    virtual std::map<int,BIA::Contato> * listar() const = 0;
    virtual void excluir(std::map<int,BIA::Contato> *M,int id_contato) const = 0;
};
#endif // CRUD_H
