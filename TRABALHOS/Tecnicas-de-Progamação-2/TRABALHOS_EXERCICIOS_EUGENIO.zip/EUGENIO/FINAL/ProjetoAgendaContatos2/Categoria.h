#ifndef CATEGORIA_H
#define CATEGORIA_H

#include <map>
#include <QString>

namespace BIA{
class Categoria
{
    std::map < int , QString > categorias;

public:
    /// \return id de uma categoria
    int buscaId (const QString& str)
    {
        for (std::map <int, QString >::const_iterator it = categorias.begin(); it != categorias.end(); ++it)
            if (it->second == str)
                return it->first;
        return -1;
    }

    ~Categoria ()
    { categorias.clear(); } // dtor do map não limpa memória

    /// adiciona ou repõe a categoria id com descrição \p descricao
    void setCategoria (int id, QString descricao)
    { categorias[id] = descricao; }

    /// \return categoria id
    QString getCategoria (int id) const
    {
        try
        {
            return categorias.at(id);
        }
        catch (...)
        {
            throw QString("Categoria::getCategoria: erro de logica");
        }
    }

    /// \return ponteiro para o map
    const std::map < int, QString >* getAll () const
    { return & categorias; }

};  /// \class Categoria

} /// \namespace BIA

#endif // CATEGORIA_H
