#ifndef ADDTELEFONE_H
#define ADDTELEFONE_H
#include "Telefone.h"
#include <QDialog>

namespace Ui {
class AddTelefone;
}

class AddTelefone : public QDialog
{
    Q_OBJECT

public:

    bool wasAdd(){return flagAdd;}
    explicit AddTelefone(QWidget *parent = 0);
    void setTelefones(std::vector<BIA::Telefone> * t,int i){ telefones = t,id  = i;}
    ~AddTelefone();

private slots:

    void on_pushButtonCancel_clicked();
    void on_pushButton_OK_clicked();

private:

    Ui::AddTelefone *ui;
    std::vector<BIA::Telefone> * telefones;
    int id;
    int flagAdd;
};

#endif // ADDTELEFONE_H
