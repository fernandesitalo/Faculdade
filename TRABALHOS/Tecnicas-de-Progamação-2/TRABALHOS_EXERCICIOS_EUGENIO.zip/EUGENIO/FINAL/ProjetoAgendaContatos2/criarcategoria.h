#ifndef CRIARCATEGORIA_H
#define CRIARCATEGORIA_H
#include <QDialog>
#include "Categoria.h"
#include "CategoriaContato.h"
#include "CategoriaContatoDAO.h"
#include "GeradorDeId.h"


namespace Ui {
class CriarCategoria;
}

class CriarCategoria : public QDialog
{
    Q_OBJECT

public:
    explicit CriarCategoria(QWidget *parent = 0);
    ~CriarCategoria();
    void setObjCategoria(BIA::Categoria * obj)
    { categ = obj;}

private slots:
    void on_botao_voltar_clicked();
    void on_botao_salvar_clicked();

private:
    Ui::CriarCategoria *ui;
    BIA::Categoria * categ;
};

#endif // CRIARCATEGORIA_H
