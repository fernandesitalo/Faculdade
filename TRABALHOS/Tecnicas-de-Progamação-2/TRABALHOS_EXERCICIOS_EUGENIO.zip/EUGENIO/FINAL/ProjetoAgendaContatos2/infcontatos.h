#ifndef INFCONTATOS_H
#define INFCONTATOS_H
#include "Contato.h"
#include <QDialog>
#include <QMessageBox>

namespace Ui {
class InfContatos;
}

class InfContatos : public QDialog
{
   Q_OBJECT

public:
    explicit InfContatos(QWidget *parent = 0);
    void SetContato(BIA::Contato * CTO,std::map<int,BIA::Contato> * contatos,std::map<QString,int> * indice,BIA::Categoria * categ)
    {
        this->CTO = CTO;
        this->contatos = contatos;
        this->indice = indice;
        this->categ = categ;
    }

    void SetInformacoesTelas();

    ~InfContatos();

private slots:
    void on_pushButton_DeletarContato_clicked();
    void on_pushButton_Sair_clicked();

private:
    Ui::InfContatos *ui;
    BIA::Contato * CTO;
    std::map<int,BIA::Contato> * contatos;
    std::map<QString,int> * indice;
    BIA::Categoria * categ;



};

#endif // INFCONTATOS_H
