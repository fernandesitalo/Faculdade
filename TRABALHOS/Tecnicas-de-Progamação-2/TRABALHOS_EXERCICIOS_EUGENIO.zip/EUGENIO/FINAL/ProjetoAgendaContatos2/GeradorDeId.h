#ifndef GERADORDEID_H
#define GERADORDEID_H 1
#include <fstream>
#include <QString>


namespace BIA
{
  class GeradorDeId
  {
    unsigned int id_atual;
    QString nome_arquivo;

  public:

    /// abre o arquivo e pega o último id usado
    GeradorDeId (const QString & arquivo) :
      id_atual(0)
    {
      nome_arquivo = arquivo;
      std::ifstream arquivo_de_id(nome_arquivo.toStdString().c_str());

      if (arquivo_de_id.is_open())
      {
        arquivo_de_id >> id_atual;
        arquivo_de_id.close();
      }
    }

    /// salva o último id usado
    ~GeradorDeId ()
    {
      std::ofstream arquivo_de_id(nome_arquivo.toStdString().c_str());
      if (arquivo_de_id.is_open())
      {
        arquivo_de_id << id_atual;
        arquivo_de_id.close();
      }
    }

    /// retorna o último id usado
    int getId () const
    {  return id_atual; }

    /// atualiza e retorna um novo último id
    int getNovoId ()
    {  return ++id_atual; }

    /// remove o id atual
    void removeId ()
    { --id_atual; }

  };  /// \class GeradorDeId

} /// \namespace BIA

#endif // GERADORDEID_H
