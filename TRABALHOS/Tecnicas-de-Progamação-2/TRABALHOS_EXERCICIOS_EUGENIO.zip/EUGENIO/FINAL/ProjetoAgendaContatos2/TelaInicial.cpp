#include "TelaInicial.h"
#include "ui_TelaInicial.h"
#include "TelaIncluirContato.h"

TelaInicial::TelaInicial(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::TelaInicial)
{
    ui->setupUi(this);
}

TelaInicial::~TelaInicial()
{
    delete ui;
}

void TelaInicial::on_pushButtonIncluir_clicked()
{
    TelaIncluirContato w;
    w.exec();
}
