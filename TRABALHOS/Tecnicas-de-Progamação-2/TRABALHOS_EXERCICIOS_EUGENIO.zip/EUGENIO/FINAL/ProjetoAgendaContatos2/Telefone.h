#ifndef TELEFONE_H
#define TELEFONE_H
#include <QString>

namespace BIA
{
  class Telefone
  {
  public:

    enum Tipo
    {
      tipo_null = 0,
      Residencial,
      Comercial,
      Trabalho
    };  /// \enum Tipo

  private:
    unsigned int idContato;
    unsigned int DDI;
    unsigned int DDD;
    unsigned int numero;
    Tipo tipo;

  public:
    Telefone ();
    Telefone (unsigned int idContato, unsigned int DDI, unsigned int DDD, unsigned int numero, Tipo tipo);
    Telefone (unsigned int idContato, unsigned int DDI, unsigned int DDD, unsigned int numero, QString tipo);

    unsigned int getIdContato() const
    { return idContato; }

    unsigned int getDDI () const
    { return DDI; }

    unsigned int getDDD () const
    { return DDD; }

    unsigned int getNumero () const
    { return numero; }

    Tipo getTipo () const
    { return tipo; }

    QString getTipoStr () const;

    void setIdContato (unsigned int idContato)
    { this->idContato=idContato; }

    void setDDI (unsigned int DDI)
    { this->DDI = DDI; }

    void setDDD (unsigned int DDD)
    { this->DDD = DDD; }

    void setNumero (unsigned int numero)
    { this->numero = numero; }

    void setTipo (Tipo tipo)
    { this->tipo = tipo; }

    void setTipo (QString tipo);

    bool operator ==(BIA::Telefone A)
    { return (this->DDD == A.DDD && this->DDI == A.DDI && this->numero == A.numero && this->idContato == A.idContato); }

  };  /// \class Telefone

} /// \namespace BIA

#endif // TELEFONE_H
