#ifndef INDICEEQ_H
#define INDICEEQ_H

#include "INDEQ.h"
#include "Equipamentos.h"

class IndiceEq
{
private:
    INDEQ * VetIndiceEq;
    int qtd;

public:
    IndiceEq();
    ~IndiceEq();

    int getqtd();



     bool VerificaUnicidadeCodigo(long long codigo); /// VERIFICA SE O Codigo E UNICO JA QUE A CHAVE DE BUSCA E por ele!!!!!!!!

     void InsereEqOrdenadoIndice(Equipamentos *B); /// insere o elemento A no vetor IND, apontado por P, ordenadamente


     bool Ehlixo(int posicao); /// e lixo ou nao?


     int BuscaNoIndice(long long int A); /// retorna posicao no INDICE

     int PosicaoNoArquivo(long long A);

     long long getcodigo(int posicaoNoIndice);

     void setLixo(bool true_or_false,int PosicaoNoIndice);

     void IsolaINDEQ(long long codigo);

     void ModificaPosicao(long long codigo,int NovaPosicao);




   // int getPosicaoNoArquivo(char *A); /// retorna posicao do nome A no indice

   // int getqtd(); /// retorna quantidade de codigos no indice

  //  void getNome(char *A,int PosicaoNoIndice);/// POSICAO DO INDICE






  //  void setLixo(bool __true_or_false__, int posicao);



  //  void IsolaINDCL(char *NomeDoCliente); /// OBJETO INDCL E "CHEGADO PARA O LADO"

  //  void ModificaPosicao(char *NomeDoCliente, int NovaPosicao); // SETA UMA NOVA POSICAO PARA ESTE NOME QUE E PASSADO COMO PARAMETRO







};

#endif // INDICEEQ_H
