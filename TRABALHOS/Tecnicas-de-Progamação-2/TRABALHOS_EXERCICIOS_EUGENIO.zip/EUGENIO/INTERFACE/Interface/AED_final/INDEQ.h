#ifndef INDEQ_H
#define INDEQ_H


class INDEQ
{
public:
    long long cod;
    int pos;
    bool lixo;

    void setINDEQ(long long codigo, int posicao);

    long long getcodigoEq();




    INDEQ();  // gts e sets necessarios
};

#endif // INDEQ_H
