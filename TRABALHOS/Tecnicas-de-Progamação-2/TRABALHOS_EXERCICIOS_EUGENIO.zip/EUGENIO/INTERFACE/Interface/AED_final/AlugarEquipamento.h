#ifndef ALUGAREQUIPAMENTO_H
#define ALUGAREQUIPAMENTO_H

#include <QDialog>
#include "INDALUGA.h"
#include <QListWidgetItem>

namespace Ui {
class AlugarEquipamento;
}

class AlugarEquipamento : public QDialog
{
    Q_OBJECT

public:
    explicit AlugarEquipamento(QWidget *parent = 0);
    ~AlugarEquipamento();

private slots:
    void on_InserirButton_clicked();

    void on_finalizarButton_clicked();

    void limpaTabela();

    void listarTodos();

    void on_listWidget_itemClicked(QListWidgetItem *item);

private:
    Ui::AlugarEquipamento *ui;
    float soma;
    int qtd;
    INDALUGA *Pedido;
};

#endif // ALUGAREQUIPAMENTO_H
