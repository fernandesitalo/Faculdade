#include "arquivo.h"
#include <fstream>
#include "games.h"
using namespace std;
#include <iostream>
#include "indice.h"
#include "cadastro.h"

arquivo::arquivo()
{
    fstream arq("games.dat",ios::out|ios::binary|ios::app);
        if(!arq.is_open())//verifica se o arquivo ja existe
        {
          ofstream arq("games.dat");
          if(!arq.is_open())
            throw 'a';
          arq.close();
        }
        arq.close();
}

void arquivo::gravarF(games *p)//grava apenas no final
{
    fstream arq("games.dat",ios::out|ios::binary|ios::app);
        if(!arq.is_open())//verifica se o arquivo ja existe
        {
          ofstream arq("games.dat");
          if(!arq.is_open())
            throw 'a';
        }
    arq.write((char*)p,sizeof(games));
    arq.close();

}

void arquivo::ler(games *p,int pos)
{
    fstream arq("games.dat",ios::in|ios::binary);
    if(!arq.is_open())
    {
        ofstream arq("games.dat");
        if(!arq.is_open())
          throw 'a';
    }

    if(pos >= getqtda())///tentar pegar de uma posiçao inexistente
        throw 7;
    arq.seekg((pos)*sizeof(games));
    arq.read((char*)p,sizeof(games));
    arq.close();

}

void arquivo::sobrescrever(games *p, int pos)
{

    fstream arq("games.dat",ios_base::binary|ios_base::in|ios_base::out);
    if(!arq.is_open())//verifica se o arquivo ja existe
    {
        ofstream arq("games.dat");
        if(!arq.is_open())
          throw 'a';

    }
    if(pos >= getqtda())///tentar gravar de uma posiçao inexistente
        throw 7;
    arq.seekp((pos)*sizeof(games),ios_base::beg);
    arq.write((char*)p,sizeof(games));
    arq.close();
}

int arquivo::getqtda()
{
    fstream arq("games.dat",ios::in|ios::binary);
    if(!arq.is_open())
    {
        ofstream arq("games.dat");
        if(!arq.is_open())
          throw 'a';
    }

    arq.seekg(0,ios_base::end);
    return arq.tellg()/sizeof(games);
}

