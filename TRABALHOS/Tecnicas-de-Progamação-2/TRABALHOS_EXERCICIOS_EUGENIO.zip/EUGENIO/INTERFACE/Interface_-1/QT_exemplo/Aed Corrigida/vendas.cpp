#include "vendas.h"

vendas::vendas()
{

}
