/********************************************************************************
** Form generated from reading UI file 'ConsultaAlugueis.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CONSULTAALUGUEIS_H
#define UI_CONSULTAALUGUEIS_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QListWidget>
#include <QtGui/QPushButton>
#include <QtGui/QTableWidget>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ConsultaAlugueis
{
public:
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QListWidget *listWidget;
    QPushButton *pushButton_2;
    QWidget *layoutWidget1;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_2;
    QLineEdit *lineEdit;
    QTableWidget *tableWidget;
    QLabel *label_4;
    QLineEdit *Preco;
    QPushButton *DevolucaoButton;
    QPushButton *pushButton;

    void setupUi(QDialog *ConsultaAlugueis)
    {
        if (ConsultaAlugueis->objectName().isEmpty())
            ConsultaAlugueis->setObjectName(QString::fromUtf8("ConsultaAlugueis"));
        ConsultaAlugueis->resize(588, 478);
        layoutWidget = new QWidget(ConsultaAlugueis);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(20, 20, 181, 441));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(layoutWidget);
        label->setObjectName(QString::fromUtf8("label"));

        verticalLayout->addWidget(label);

        listWidget = new QListWidget(layoutWidget);
        listWidget->setObjectName(QString::fromUtf8("listWidget"));
        listWidget->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        verticalLayout->addWidget(listWidget);

        pushButton_2 = new QPushButton(layoutWidget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));

        verticalLayout->addWidget(pushButton_2);

        layoutWidget1 = new QWidget(ConsultaAlugueis);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(230, 20, 341, 441));
        verticalLayout_2 = new QVBoxLayout(layoutWidget1);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        label_2 = new QLabel(layoutWidget1);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        verticalLayout_2->addWidget(label_2);

        lineEdit = new QLineEdit(layoutWidget1);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setEnabled(false);
        lineEdit->setMinimumSize(QSize(0, 1));
        QFont font;
        font.setPointSize(10);
        font.setBold(true);
        font.setItalic(true);
        font.setWeight(75);
        lineEdit->setFont(font);
        lineEdit->setCursor(QCursor(Qt::ForbiddenCursor));

        verticalLayout_2->addWidget(lineEdit);

        tableWidget = new QTableWidget(layoutWidget1);
        if (tableWidget->columnCount() < 3)
            tableWidget->setColumnCount(3);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));

        verticalLayout_2->addWidget(tableWidget);

        label_4 = new QLabel(layoutWidget1);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        verticalLayout_2->addWidget(label_4);

        Preco = new QLineEdit(layoutWidget1);
        Preco->setObjectName(QString::fromUtf8("Preco"));
        Preco->setEnabled(false);
        Preco->setFont(font);
        Preco->setCursor(QCursor(Qt::BlankCursor));

        verticalLayout_2->addWidget(Preco);

        DevolucaoButton = new QPushButton(layoutWidget1);
        DevolucaoButton->setObjectName(QString::fromUtf8("DevolucaoButton"));

        verticalLayout_2->addWidget(DevolucaoButton);

        pushButton = new QPushButton(layoutWidget1);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        verticalLayout_2->addWidget(pushButton);


        retranslateUi(ConsultaAlugueis);

        QMetaObject::connectSlotsByName(ConsultaAlugueis);
    } // setupUi

    void retranslateUi(QDialog *ConsultaAlugueis)
    {
        ConsultaAlugueis->setWindowTitle(QApplication::translate("ConsultaAlugueis", "Dialog", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("ConsultaAlugueis", "<html><head/><body><p><span style=\" font-weight:600; color:#f5f5f5;\">Alugueis em Aberto:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        pushButton_2->setText(QApplication::translate("ConsultaAlugueis", "Listar todos \n"
"Alugueis em Aberto", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("ConsultaAlugueis", "<html><head/><body><p><span style=\" font-weight:600; color:#fafafa;\">Nome do Cliente:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem = tableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("ConsultaAlugueis", "Nome", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("ConsultaAlugueis", "Quantidade", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("ConsultaAlugueis", "Valor", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("ConsultaAlugueis", "<html><head/><body><p><span style=\" font-weight:600; color:#ffffff;\">Pre\303\247o do Total do Aluguel:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        Preco->setText(QApplication::translate("ConsultaAlugueis", "R$", 0, QApplication::UnicodeUTF8));
        DevolucaoButton->setText(QApplication::translate("ConsultaAlugueis", "CONFIRMAR DEVOLU\303\207\303\203O", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("ConsultaAlugueis", "VOLTAR", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class ConsultaAlugueis: public Ui_ConsultaAlugueis {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CONSULTAALUGUEIS_H
