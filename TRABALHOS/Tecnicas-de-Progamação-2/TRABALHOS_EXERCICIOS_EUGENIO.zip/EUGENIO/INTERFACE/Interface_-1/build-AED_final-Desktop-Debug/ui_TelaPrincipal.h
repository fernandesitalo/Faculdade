/********************************************************************************
** Form generated from reading UI file 'TelaPrincipal.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TELAPRINCIPAL_H
#define UI_TELAPRINCIPAL_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QMainWindow>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_TelaPrincipal
{
public:
    QWidget *centralWidget;
    QPushButton *AtualizarEquipamentoButton;
    QPushButton *AtualizarClienteButton;
    QPushButton *CadrastroEquipamentosButton;
    QPushButton *AlugarButton;
    QPushButton *CadrastrarClienteButton;
    QPushButton *LixeiraButton;
    QPushButton *AlugarButton_2;
    QPushButton *pushButton;
    QLabel *label;

    void setupUi(QMainWindow *TelaPrincipal)
    {
        if (TelaPrincipal->objectName().isEmpty())
            TelaPrincipal->setObjectName(QString::fromUtf8("TelaPrincipal"));
        TelaPrincipal->setEnabled(true);
        TelaPrincipal->resize(775, 486);
        TelaPrincipal->setMinimumSize(QSize(775, 486));
        TelaPrincipal->setMaximumSize(QSize(775, 486));
        QFont font;
        font.setStyleStrategy(QFont::PreferDefault);
        TelaPrincipal->setFont(font);
        TelaPrincipal->setAcceptDrops(false);
        TelaPrincipal->setStyleSheet(QString::fromUtf8("image: url(:/imagens/imagem.jpg);"));
        centralWidget = new QWidget(TelaPrincipal);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        AtualizarEquipamentoButton = new QPushButton(centralWidget);
        AtualizarEquipamentoButton->setObjectName(QString::fromUtf8("AtualizarEquipamentoButton"));
        AtualizarEquipamentoButton->setGeometry(QRect(500, 330, 271, 51));
        QFont font1;
        font1.setPointSize(11);
        font1.setBold(false);
        font1.setItalic(true);
        font1.setWeight(50);
        AtualizarEquipamentoButton->setFont(font1);
        AtualizarClienteButton = new QPushButton(centralWidget);
        AtualizarClienteButton->setObjectName(QString::fromUtf8("AtualizarClienteButton"));
        AtualizarClienteButton->setGeometry(QRect(10, 330, 271, 51));
        AtualizarClienteButton->setFont(font1);
        CadrastroEquipamentosButton = new QPushButton(centralWidget);
        CadrastroEquipamentosButton->setObjectName(QString::fromUtf8("CadrastroEquipamentosButton"));
        CadrastroEquipamentosButton->setGeometry(QRect(500, 270, 271, 51));
        CadrastroEquipamentosButton->setFont(font1);
        AlugarButton = new QPushButton(centralWidget);
        AlugarButton->setObjectName(QString::fromUtf8("AlugarButton"));
        AlugarButton->setGeometry(QRect(10, 210, 271, 51));
        AlugarButton->setFont(font1);
        AlugarButton->setStyleSheet(QString::fromUtf8(""));
        CadrastrarClienteButton = new QPushButton(centralWidget);
        CadrastrarClienteButton->setObjectName(QString::fromUtf8("CadrastrarClienteButton"));
        CadrastrarClienteButton->setGeometry(QRect(10, 270, 271, 51));
        CadrastrarClienteButton->setFont(font1);
        CadrastrarClienteButton->setCursor(QCursor(Qt::PointingHandCursor));
        CadrastrarClienteButton->setStyleSheet(QString::fromUtf8(""));
        LixeiraButton = new QPushButton(centralWidget);
        LixeiraButton->setObjectName(QString::fromUtf8("LixeiraButton"));
        LixeiraButton->setGeometry(QRect(10, 390, 271, 31));
        LixeiraButton->setFont(font1);
        AlugarButton_2 = new QPushButton(centralWidget);
        AlugarButton_2->setObjectName(QString::fromUtf8("AlugarButton_2"));
        AlugarButton_2->setGeometry(QRect(500, 210, 271, 51));
        AlugarButton_2->setFont(font1);
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(500, 390, 271, 31));
        QFont font2;
        font2.setPointSize(10);
        font2.setBold(false);
        font2.setItalic(true);
        font2.setWeight(50);
        pushButton->setFont(font2);
        label = new QLabel(centralWidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(-150, -190, 1041, 971));
        QFont font3;
        font3.setFamily(QString::fromUtf8("Sans"));
        font3.setPointSize(35);
        font3.setBold(false);
        font3.setItalic(false);
        font3.setWeight(50);
        label->setFont(font3);
        label->setStyleSheet(QString::fromUtf8("selection-color: rgb(185, 185, 255);\n"
""));
        TelaPrincipal->setCentralWidget(centralWidget);
        label->raise();
        AtualizarEquipamentoButton->raise();
        AtualizarClienteButton->raise();
        CadrastroEquipamentosButton->raise();
        AlugarButton->raise();
        CadrastrarClienteButton->raise();
        LixeiraButton->raise();
        AlugarButton_2->raise();
        pushButton->raise();

        retranslateUi(TelaPrincipal);

        QMetaObject::connectSlotsByName(TelaPrincipal);
    } // setupUi

    void retranslateUi(QMainWindow *TelaPrincipal)
    {
        TelaPrincipal->setWindowTitle(QApplication::translate("TelaPrincipal", "TelaPrincipal", 0, QApplication::UnicodeUTF8));
        AtualizarEquipamentoButton->setText(QApplication::translate("TelaPrincipal", "CONSULTAR EQUIPAMENTOS", 0, QApplication::UnicodeUTF8));
        AtualizarClienteButton->setText(QApplication::translate("TelaPrincipal", "CONSULTAR CLIENTES", 0, QApplication::UnicodeUTF8));
        CadrastroEquipamentosButton->setText(QApplication::translate("TelaPrincipal", "CADRASTRAR EQUIPAMENTOS", 0, QApplication::UnicodeUTF8));
        AlugarButton->setText(QApplication::translate("TelaPrincipal", "ALUGAR EQUIPAMENTOS", 0, QApplication::UnicodeUTF8));
        AlugarButton->setShortcut(QString());
        CadrastrarClienteButton->setText(QApplication::translate("TelaPrincipal", "CADRASTRAR CLIENTES", 0, QApplication::UnicodeUTF8));
        LixeiraButton->setText(QApplication::translate("TelaPrincipal", "Esvaziar Lixeira", 0, QApplication::UnicodeUTF8));
        AlugarButton_2->setText(QApplication::translate("TelaPrincipal", "CONSULTAR ALUGUEIS", 0, QApplication::UnicodeUTF8));
        AlugarButton_2->setShortcut(QString());
        pushButton->setText(QApplication::translate("TelaPrincipal", "Sair", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("TelaPrincipal", "<html><head/><body><p align=\"center\"><span style=\" font-size:48pt; font-weight:600; text-decoration: underline; color:#ffffff;\">C</span><span style=\" font-weight:600; color:#ffffff;\">ONSTRU</span><span style=\" font-size:48pt; font-weight:600; text-decoration: underline; color:#ffffff;\">C</span><span style=\" font-weight:600; color:#ffffff;\">TOR</span><br/></p><p align=\"center\"><br/></p><p align=\"center\"><br/></p><p align=\"center\"><br/></p></body></html>", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class TelaPrincipal: public Ui_TelaPrincipal {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TELAPRINCIPAL_H
