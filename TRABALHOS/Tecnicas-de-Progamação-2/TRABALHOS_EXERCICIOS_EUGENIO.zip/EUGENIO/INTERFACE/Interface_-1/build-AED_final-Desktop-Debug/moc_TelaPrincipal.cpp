/****************************************************************************
** Meta object code from reading C++ file 'TelaPrincipal.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.7)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../AED_final/TelaPrincipal.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'TelaPrincipal.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_TelaPrincipal[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       8,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      15,   14,   14,   14, 0x08,
      52,   14,   14,   14, 0x08,
      88,   14,   14,   14, 0x08,
     115,   14,   14,   14, 0x08,
     156,   14,   14,   14, 0x08,
     196,   14,   14,   14, 0x08,
     222,   14,   14,   14, 0x08,
     250,   14,   14,   14, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_TelaPrincipal[] = {
    "TelaPrincipal\0\0on_CadrastrarClienteButton_clicked()\0"
    "on_AtualizarClienteButton_clicked()\0"
    "on_LixeiraButton_clicked()\0"
    "on_CadrastroEquipamentosButton_clicked()\0"
    "on_AtualizarEquipamentoButton_clicked()\0"
    "on_AlugarButton_clicked()\0"
    "on_AlugarButton_2_clicked()\0"
    "on_pushButton_clicked()\0"
};

void TelaPrincipal::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        TelaPrincipal *_t = static_cast<TelaPrincipal *>(_o);
        switch (_id) {
        case 0: _t->on_CadrastrarClienteButton_clicked(); break;
        case 1: _t->on_AtualizarClienteButton_clicked(); break;
        case 2: _t->on_LixeiraButton_clicked(); break;
        case 3: _t->on_CadrastroEquipamentosButton_clicked(); break;
        case 4: _t->on_AtualizarEquipamentoButton_clicked(); break;
        case 5: _t->on_AlugarButton_clicked(); break;
        case 6: _t->on_AlugarButton_2_clicked(); break;
        case 7: _t->on_pushButton_clicked(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObjectExtraData TelaPrincipal::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject TelaPrincipal::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_TelaPrincipal,
      qt_meta_data_TelaPrincipal, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &TelaPrincipal::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *TelaPrincipal::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *TelaPrincipal::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_TelaPrincipal))
        return static_cast<void*>(const_cast< TelaPrincipal*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int TelaPrincipal::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
