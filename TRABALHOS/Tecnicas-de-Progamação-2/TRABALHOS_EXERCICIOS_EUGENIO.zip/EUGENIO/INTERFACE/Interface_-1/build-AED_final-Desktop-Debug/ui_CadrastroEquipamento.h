/********************************************************************************
** Form generated from reading UI file 'CadrastroEquipamento.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CADRASTROEQUIPAMENTO_H
#define UI_CADRASTROEQUIPAMENTO_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QFrame>
#include <QtGui/QGridLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_CadrastroEquipamento
{
public:
    QFrame *line_5;
    QFrame *line_6;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QLabel *label_3;
    QLineEdit *linecodigo;
    QLabel *label;
    QLineEdit *linenome;
    QLabel *label_2;
    QLineEdit *linepreco;
    QLabel *label_5;
    QLineEdit *linedescricao;
    QLabel *label_6;
    QLineEdit *linequantidade;
    QGridLayout *gridLayout;
    QPushButton *cadrastrarButton;
    QPushButton *cancelarButton;
    QLabel *label_4;

    void setupUi(QDialog *CadrastroEquipamento)
    {
        if (CadrastroEquipamento->objectName().isEmpty())
            CadrastroEquipamento->setObjectName(QString::fromUtf8("CadrastroEquipamento"));
        CadrastroEquipamento->resize(542, 377);
        line_5 = new QFrame(CadrastroEquipamento);
        line_5->setObjectName(QString::fromUtf8("line_5"));
        line_5->setGeometry(QRect(540, 160, 231, 16));
        line_5->setFrameShape(QFrame::HLine);
        line_5->setFrameShadow(QFrame::Sunken);
        line_6 = new QFrame(CadrastroEquipamento);
        line_6->setObjectName(QString::fromUtf8("line_6"));
        line_6->setGeometry(QRect(700, -60, 71, 481));
        line_6->setFrameShape(QFrame::VLine);
        line_6->setFrameShadow(QFrame::Sunken);
        layoutWidget = new QWidget(CadrastroEquipamento);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(10, 10, 521, 359));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setEnabled(false);

        verticalLayout->addWidget(label_3);

        linecodigo = new QLineEdit(layoutWidget);
        linecodigo->setObjectName(QString::fromUtf8("linecodigo"));

        verticalLayout->addWidget(linecodigo);

        label = new QLabel(layoutWidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setEnabled(false);

        verticalLayout->addWidget(label);

        linenome = new QLineEdit(layoutWidget);
        linenome->setObjectName(QString::fromUtf8("linenome"));

        verticalLayout->addWidget(linenome);

        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setEnabled(false);

        verticalLayout->addWidget(label_2);

        linepreco = new QLineEdit(layoutWidget);
        linepreco->setObjectName(QString::fromUtf8("linepreco"));

        verticalLayout->addWidget(linepreco);

        label_5 = new QLabel(layoutWidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setEnabled(false);

        verticalLayout->addWidget(label_5);

        linedescricao = new QLineEdit(layoutWidget);
        linedescricao->setObjectName(QString::fromUtf8("linedescricao"));

        verticalLayout->addWidget(linedescricao);

        label_6 = new QLabel(layoutWidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setEnabled(false);

        verticalLayout->addWidget(label_6);

        linequantidade = new QLineEdit(layoutWidget);
        linequantidade->setObjectName(QString::fromUtf8("linequantidade"));

        verticalLayout->addWidget(linequantidade);

        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        cadrastrarButton = new QPushButton(layoutWidget);
        cadrastrarButton->setObjectName(QString::fromUtf8("cadrastrarButton"));
        QFont font;
        font.setPointSize(11);
        font.setBold(false);
        font.setItalic(true);
        font.setWeight(50);
        cadrastrarButton->setFont(font);

        gridLayout->addWidget(cadrastrarButton, 0, 1, 1, 1);

        cancelarButton = new QPushButton(layoutWidget);
        cancelarButton->setObjectName(QString::fromUtf8("cancelarButton"));
        cancelarButton->setFont(font);

        gridLayout->addWidget(cancelarButton, 0, 2, 1, 1);


        verticalLayout->addLayout(gridLayout);

        label_4 = new QLabel(CadrastroEquipamento);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(-20, 0, 571, 381));
        label_4->setStyleSheet(QString::fromUtf8("border-image: url(:/WP4PH4N6.jpg);"));
        label_4->raise();
        line_5->raise();
        line_6->raise();
        layoutWidget->raise();

        retranslateUi(CadrastroEquipamento);

        QMetaObject::connectSlotsByName(CadrastroEquipamento);
    } // setupUi

    void retranslateUi(QDialog *CadrastroEquipamento)
    {
        CadrastroEquipamento->setWindowTitle(QApplication::translate("CadrastroEquipamento", "Dialog", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("CadrastroEquipamento", "C\303\263digo Num\303\251rico do Equipamento: **", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("CadrastroEquipamento", "Nome: **", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("CadrastroEquipamento", "Pre\303\247o de Aluguel: **", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("CadrastroEquipamento", "Descri\303\247\303\243o:", 0, QApplication::UnicodeUTF8));
        label_6->setText(QApplication::translate("CadrastroEquipamento", "Quantidade de Estoque: **", 0, QApplication::UnicodeUTF8));
        cadrastrarButton->setText(QApplication::translate("CadrastroEquipamento", "CADRASTRAR", 0, QApplication::UnicodeUTF8));
        cancelarButton->setText(QApplication::translate("CadrastroEquipamento", "VOLTAR", 0, QApplication::UnicodeUTF8));
        label_4->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class CadrastroEquipamento: public Ui_CadrastroEquipamento {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CADRASTROEQUIPAMENTO_H
