/********************************************************************************
** Form generated from reading UI file 'AtualizarEquipamento.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ATUALIZAREQUIPAMENTO_H
#define UI_ATUALIZAREQUIPAMENTO_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QFrame>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QListWidget>
#include <QtGui/QPushButton>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AtualizarEquipamento
{
public:
    QListWidget *listWidget;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout;
    QPushButton *ApagarButton;
    QPushButton *cancelarButton;
    QPushButton *atualizarButton;
    QLineEdit *lineCOD;
    QPushButton *BuscaButton;
    QPushButton *ListarButton;
    QFrame *line;
    QFrame *line_2;
    QFrame *line_3;
    QFrame *line_4;
    QWidget *layoutWidget1;
    QVBoxLayout *verticalLayout;
    QLabel *label_3;
    QLineEdit *linecodigo;
    QLabel *label;
    QLineEdit *linenome;
    QLabel *label_2;
    QLineEdit *linepreco;
    QLabel *label_5;
    QLineEdit *linedescricao;
    QLabel *label_10;
    QLineEdit *lineqtd;

    void setupUi(QDialog *AtualizarEquipamento)
    {
        if (AtualizarEquipamento->objectName().isEmpty())
            AtualizarEquipamento->setObjectName(QString::fromUtf8("AtualizarEquipamento"));
        AtualizarEquipamento->resize(708, 441);
        AtualizarEquipamento->setStyleSheet(QString::fromUtf8(""));
        listWidget = new QListWidget(AtualizarEquipamento);
        listWidget->setObjectName(QString::fromUtf8("listWidget"));
        listWidget->setGeometry(QRect(21, 90, 121, 291));
        listWidget->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        layoutWidget = new QWidget(AtualizarEquipamento);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(160, 370, 531, 61));
        horizontalLayout = new QHBoxLayout(layoutWidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        ApagarButton = new QPushButton(layoutWidget);
        ApagarButton->setObjectName(QString::fromUtf8("ApagarButton"));

        horizontalLayout->addWidget(ApagarButton);

        cancelarButton = new QPushButton(layoutWidget);
        cancelarButton->setObjectName(QString::fromUtf8("cancelarButton"));

        horizontalLayout->addWidget(cancelarButton);

        atualizarButton = new QPushButton(layoutWidget);
        atualizarButton->setObjectName(QString::fromUtf8("atualizarButton"));

        horizontalLayout->addWidget(atualizarButton);

        lineCOD = new QLineEdit(AtualizarEquipamento);
        lineCOD->setObjectName(QString::fromUtf8("lineCOD"));
        lineCOD->setGeometry(QRect(20, 30, 121, 23));
        BuscaButton = new QPushButton(AtualizarEquipamento);
        BuscaButton->setObjectName(QString::fromUtf8("BuscaButton"));
        BuscaButton->setGeometry(QRect(20, 60, 121, 21));
        ListarButton = new QPushButton(AtualizarEquipamento);
        ListarButton->setObjectName(QString::fromUtf8("ListarButton"));
        ListarButton->setGeometry(QRect(30, 390, 101, 41));
        line = new QFrame(AtualizarEquipamento);
        line->setObjectName(QString::fromUtf8("line"));
        line->setGeometry(QRect(-10, 0, 841, 16));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);
        line_2 = new QFrame(AtualizarEquipamento);
        line_2->setObjectName(QString::fromUtf8("line_2"));
        line_2->setGeometry(QRect(0, 425, 781, 21));
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);
        line_3 = new QFrame(AtualizarEquipamento);
        line_3->setObjectName(QString::fromUtf8("line_3"));
        line_3->setGeometry(QRect(129, -60, 41, 511));
        line_3->setFrameShape(QFrame::VLine);
        line_3->setFrameShadow(QFrame::Sunken);
        line_4 = new QFrame(AtualizarEquipamento);
        line_4->setObjectName(QString::fromUtf8("line_4"));
        line_4->setGeometry(QRect(-20, -20, 61, 511));
        line_4->setFrameShape(QFrame::VLine);
        line_4->setFrameShadow(QFrame::Sunken);
        layoutWidget1 = new QWidget(AtualizarEquipamento);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(162, 33, 531, 321));
        verticalLayout = new QVBoxLayout(layoutWidget1);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        label_3 = new QLabel(layoutWidget1);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        verticalLayout->addWidget(label_3);

        linecodigo = new QLineEdit(layoutWidget1);
        linecodigo->setObjectName(QString::fromUtf8("linecodigo"));
        linecodigo->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        verticalLayout->addWidget(linecodigo);

        label = new QLabel(layoutWidget1);
        label->setObjectName(QString::fromUtf8("label"));

        verticalLayout->addWidget(label);

        linenome = new QLineEdit(layoutWidget1);
        linenome->setObjectName(QString::fromUtf8("linenome"));
        linenome->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        verticalLayout->addWidget(linenome);

        label_2 = new QLabel(layoutWidget1);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        verticalLayout->addWidget(label_2);

        linepreco = new QLineEdit(layoutWidget1);
        linepreco->setObjectName(QString::fromUtf8("linepreco"));
        linepreco->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        verticalLayout->addWidget(linepreco);

        label_5 = new QLabel(layoutWidget1);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        verticalLayout->addWidget(label_5);

        linedescricao = new QLineEdit(layoutWidget1);
        linedescricao->setObjectName(QString::fromUtf8("linedescricao"));
        linedescricao->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        verticalLayout->addWidget(linedescricao);

        label_10 = new QLabel(layoutWidget1);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setEnabled(true);

        verticalLayout->addWidget(label_10);

        lineqtd = new QLineEdit(layoutWidget1);
        lineqtd->setObjectName(QString::fromUtf8("lineqtd"));
        lineqtd->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        verticalLayout->addWidget(lineqtd);

        layoutWidget->raise();
        listWidget->raise();
        layoutWidget->raise();
        lineCOD->raise();
        BuscaButton->raise();
        ListarButton->raise();
        line->raise();
        line_2->raise();
        line_3->raise();
        line_4->raise();

        retranslateUi(AtualizarEquipamento);

        QMetaObject::connectSlotsByName(AtualizarEquipamento);
    } // setupUi

    void retranslateUi(QDialog *AtualizarEquipamento)
    {
        AtualizarEquipamento->setWindowTitle(QApplication::translate("AtualizarEquipamento", "Dialog", 0, QApplication::UnicodeUTF8));
        ApagarButton->setText(QApplication::translate("AtualizarEquipamento", "APAGAR CADRASTRO", 0, QApplication::UnicodeUTF8));
        cancelarButton->setText(QApplication::translate("AtualizarEquipamento", "CANCELAR", 0, QApplication::UnicodeUTF8));
        atualizarButton->setText(QApplication::translate("AtualizarEquipamento", "ATUALIZAR CADRASTRO", 0, QApplication::UnicodeUTF8));
        BuscaButton->setText(QApplication::translate("AtualizarEquipamento", "Buscar por C\303\263digo", 0, QApplication::UnicodeUTF8));
        ListarButton->setText(QApplication::translate("AtualizarEquipamento", "Listar\n"
"Equipamentos", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("AtualizarEquipamento", "<html><head/><body><p><span style=\" color:#100c0c;\">C\303\263digo: **</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("AtualizarEquipamento", "<html><head/><body><p><span style=\" color:#140404;\">Nome: **</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("AtualizarEquipamento", "<html><head/><body><p><span style=\" color:#150707;\">Pre\303\247o de Aluguel **</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("AtualizarEquipamento", "<html><head/><body><p><span style=\" color:#1f0909;\">Descri\303\247\303\243o:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_10->setText(QApplication::translate("AtualizarEquipamento", "<html><head/><body><p><span style=\" color:#1b1111;\">Quantidade disponivel no Estoque: **</span></p></body></html>", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class AtualizarEquipamento: public Ui_AtualizarEquipamento {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ATUALIZAREQUIPAMENTO_H
