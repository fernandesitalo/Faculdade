/****************************************************************************
** Meta object code from reading C++ file 'AlugarEquipamento.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.7)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../AED_final/AlugarEquipamento.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'AlugarEquipamento.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_AlugarEquipamento[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      10,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      19,   18,   18,   18, 0x08,
      46,   18,   18,   18, 0x08,
      75,   18,   18,   18, 0x08,
      89,   18,   18,   18, 0x08,
     108,  103,   18,   18, 0x08,
     152,   18,   18,   18, 0x08,
     177,   18,   18,   18, 0x08,
     203,   18,   18,   18, 0x08,
     227,   18,   18,   18, 0x08,
     258,   18,   18,   18, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_AlugarEquipamento[] = {
    "AlugarEquipamento\0\0on_InserirButton_clicked()\0"
    "on_finalizarButton_clicked()\0limpaTabela()\0"
    "listarTodos()\0item\0"
    "on_listWidget_itemClicked(QListWidgetItem*)\0"
    "on_DeletButton_clicked()\0"
    "on_pushButton_2_clicked()\0"
    "on_pushButton_clicked()\0"
    "on_finalizarButton_2_clicked()\0"
    "on_finalizarButton_3_clicked()\0"
};

void AlugarEquipamento::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        AlugarEquipamento *_t = static_cast<AlugarEquipamento *>(_o);
        switch (_id) {
        case 0: _t->on_InserirButton_clicked(); break;
        case 1: _t->on_finalizarButton_clicked(); break;
        case 2: _t->limpaTabela(); break;
        case 3: _t->listarTodos(); break;
        case 4: _t->on_listWidget_itemClicked((*reinterpret_cast< QListWidgetItem*(*)>(_a[1]))); break;
        case 5: _t->on_DeletButton_clicked(); break;
        case 6: _t->on_pushButton_2_clicked(); break;
        case 7: _t->on_pushButton_clicked(); break;
        case 8: _t->on_finalizarButton_2_clicked(); break;
        case 9: _t->on_finalizarButton_3_clicked(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData AlugarEquipamento::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject AlugarEquipamento::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_AlugarEquipamento,
      qt_meta_data_AlugarEquipamento, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &AlugarEquipamento::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *AlugarEquipamento::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *AlugarEquipamento::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_AlugarEquipamento))
        return static_cast<void*>(const_cast< AlugarEquipamento*>(this));
    return QDialog::qt_metacast(_clname);
}

int AlugarEquipamento::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 10)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
