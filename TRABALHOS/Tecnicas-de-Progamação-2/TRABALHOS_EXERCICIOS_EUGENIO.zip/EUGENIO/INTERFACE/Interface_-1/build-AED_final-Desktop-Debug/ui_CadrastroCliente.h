/********************************************************************************
** Form generated from reading UI file 'CadrastroCliente.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CADRASTROCLIENTE_H
#define UI_CADRASTROCLIENTE_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_CadrastroCliente
{
public:
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QLineEdit *linenome;
    QLabel *label_2;
    QLineEdit *linecpf;
    QLabel *label_5;
    QLineEdit *lineendereco;
    QLabel *label_3;
    QLineEdit *linefone;
    QWidget *layoutWidget1;
    QHBoxLayout *horizontalLayout;
    QPushButton *cadrastrarButton;
    QPushButton *cancelarButton;
    QLabel *label_4;

    void setupUi(QDialog *CadrastroCliente)
    {
        if (CadrastroCliente->objectName().isEmpty())
            CadrastroCliente->setObjectName(QString::fromUtf8("CadrastroCliente"));
        CadrastroCliente->resize(645, 356);
        layoutWidget = new QWidget(CadrastroCliente);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(10, 10, 621, 291));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(layoutWidget);
        label->setObjectName(QString::fromUtf8("label"));

        verticalLayout->addWidget(label);

        linenome = new QLineEdit(layoutWidget);
        linenome->setObjectName(QString::fromUtf8("linenome"));

        verticalLayout->addWidget(linenome);

        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        verticalLayout->addWidget(label_2);

        linecpf = new QLineEdit(layoutWidget);
        linecpf->setObjectName(QString::fromUtf8("linecpf"));

        verticalLayout->addWidget(linecpf);

        label_5 = new QLabel(layoutWidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        verticalLayout->addWidget(label_5);

        lineendereco = new QLineEdit(layoutWidget);
        lineendereco->setObjectName(QString::fromUtf8("lineendereco"));

        verticalLayout->addWidget(lineendereco);

        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        verticalLayout->addWidget(label_3);

        linefone = new QLineEdit(layoutWidget);
        linefone->setObjectName(QString::fromUtf8("linefone"));

        verticalLayout->addWidget(linefone);

        layoutWidget1 = new QWidget(CadrastroCliente);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(10, 310, 621, 32));
        horizontalLayout = new QHBoxLayout(layoutWidget1);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        cadrastrarButton = new QPushButton(layoutWidget1);
        cadrastrarButton->setObjectName(QString::fromUtf8("cadrastrarButton"));
        QFont font;
        font.setPointSize(11);
        font.setBold(false);
        font.setItalic(true);
        font.setWeight(50);
        cadrastrarButton->setFont(font);

        horizontalLayout->addWidget(cadrastrarButton);

        cancelarButton = new QPushButton(layoutWidget1);
        cancelarButton->setObjectName(QString::fromUtf8("cancelarButton"));
        cancelarButton->setFont(font);

        horizontalLayout->addWidget(cancelarButton);

        cancelarButton->raise();
        cadrastrarButton->raise();
        label_4 = new QLabel(CadrastroCliente);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(350, 0, 61, 15));

        retranslateUi(CadrastroCliente);

        QMetaObject::connectSlotsByName(CadrastroCliente);
    } // setupUi

    void retranslateUi(QDialog *CadrastroCliente)
    {
        CadrastroCliente->setWindowTitle(QApplication::translate("CadrastroCliente", "Dialog", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("CadrastroCliente", "<html><head/><body><p><span style=\" color:#181111;\">Nome/Raz\303\243o social:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("CadrastroCliente", "<html><head/><body><p><span style=\" color:#101010;\">Cpf/Cnpj:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("CadrastroCliente", "<html><head/><body><p><span style=\" color:#1d0f0f;\">Endere\303\247o:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("CadrastroCliente", "<html><head/><body><p><span style=\" color:#1f1a1a;\">Fone:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        cadrastrarButton->setText(QApplication::translate("CadrastroCliente", "CADRASTRAR ", 0, QApplication::UnicodeUTF8));
        cancelarButton->setText(QApplication::translate("CadrastroCliente", "VOLTAR", 0, QApplication::UnicodeUTF8));
        label_4->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class CadrastroCliente: public Ui_CadrastroCliente {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CADRASTROCLIENTE_H
