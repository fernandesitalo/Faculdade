/********************************************************************************
** Form generated from reading UI file 'NomesCodigos.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NOMESCODIGOS_H
#define UI_NOMESCODIGOS_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QTableWidget>

QT_BEGIN_NAMESPACE

class Ui_NomesCodigos
{
public:
    QTableWidget *tableWidget;

    void setupUi(QDialog *NomesCodigos)
    {
        if (NomesCodigos->objectName().isEmpty())
            NomesCodigos->setObjectName(QString::fromUtf8("NomesCodigos"));
        NomesCodigos->resize(343, 348);
        NomesCodigos->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 255, 0);\n"
"background-color: rgb(0, 0, 0);"));
        tableWidget = new QTableWidget(NomesCodigos);
        if (tableWidget->columnCount() < 2)
            tableWidget->setColumnCount(2);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));
        tableWidget->setGeometry(QRect(10, 10, 321, 331));
        tableWidget->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
""));
        tableWidget->setMidLineWidth(0);
        tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
        tableWidget->setColumnCount(2);
        tableWidget->horizontalHeader()->setDefaultSectionSize(150);

        retranslateUi(NomesCodigos);

        QMetaObject::connectSlotsByName(NomesCodigos);
    } // setupUi

    void retranslateUi(QDialog *NomesCodigos)
    {
        NomesCodigos->setWindowTitle(QApplication::translate("NomesCodigos", "Dialog", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem = tableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("NomesCodigos", "Nome ", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("NomesCodigos", "C\303\263digo", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class NomesCodigos: public Ui_NomesCodigos {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NOMESCODIGOS_H
