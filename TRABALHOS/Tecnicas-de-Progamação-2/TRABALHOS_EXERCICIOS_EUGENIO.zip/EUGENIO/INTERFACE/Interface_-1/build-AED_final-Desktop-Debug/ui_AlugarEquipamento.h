/********************************************************************************
** Form generated from reading UI file 'AlugarEquipamento.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ALUGAREQUIPAMENTO_H
#define UI_ALUGAREQUIPAMENTO_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QListWidget>
#include <QtGui/QPushButton>
#include <QtGui/QTableWidget>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AlugarEquipamento
{
public:
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLabel *label_3;
    QLabel *label_2;
    QTableWidget *tableWidget;
    QLabel *label_4;
    QLineEdit *linePrecoTotoal;
    QListWidget *listWidget;
    QPushButton *InserirButton;
    QLabel *label_6;
    QLineEdit *qtdedit;
    QLineEdit *linecodigo;
    QLabel *label_7;
    QPushButton *finalizarButton;
    QLineEdit *linecliente;
    QPushButton *pushButton;
    QPushButton *DeletButton;
    QLabel *label_8;
    QLineEdit *LineCodDelet;
    QPushButton *pushButton_2;
    QLabel *label_5;
    QLineEdit *lineEdit;
    QPushButton *finalizarButton_2;
    QPushButton *finalizarButton_3;
    QLabel *label_9;

    void setupUi(QDialog *AlugarEquipamento)
    {
        if (AlugarEquipamento->objectName().isEmpty())
            AlugarEquipamento->setObjectName(QString::fromUtf8("AlugarEquipamento"));
        AlugarEquipamento->resize(665, 614);
        layoutWidget = new QWidget(AlugarEquipamento);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(10, 80, 331, 451));
        verticalLayout_3 = new QVBoxLayout(layoutWidget);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label = new QLabel(layoutWidget);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout->addWidget(label_3);

        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout->addWidget(label_2);


        verticalLayout_3->addLayout(horizontalLayout);

        tableWidget = new QTableWidget(layoutWidget);
        if (tableWidget->columnCount() < 3)
            tableWidget->setColumnCount(3);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));
        tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
        tableWidget->setColumnCount(3);

        verticalLayout_3->addWidget(tableWidget);

        label_4 = new QLabel(layoutWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        verticalLayout_3->addWidget(label_4);

        linePrecoTotoal = new QLineEdit(layoutWidget);
        linePrecoTotoal->setObjectName(QString::fromUtf8("linePrecoTotoal"));
        linePrecoTotoal->setReadOnly(true);

        verticalLayout_3->addWidget(linePrecoTotoal);

        listWidget = new QListWidget(AlugarEquipamento);
        listWidget->setObjectName(QString::fromUtf8("listWidget"));
        listWidget->setGeometry(QRect(420, 340, 221, 161));
        InserirButton = new QPushButton(AlugarEquipamento);
        InserirButton->setObjectName(QString::fromUtf8("InserirButton"));
        InserirButton->setGeometry(QRect(420, 120, 221, 61));
        QFont font;
        font.setPointSize(11);
        font.setBold(false);
        font.setItalic(true);
        font.setWeight(50);
        InserirButton->setFont(font);
        InserirButton->setAutoDefault(true);
        label_6 = new QLabel(AlugarEquipamento);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(420, 20, 221, 17));
        qtdedit = new QLineEdit(AlugarEquipamento);
        qtdedit->setObjectName(QString::fromUtf8("qtdedit"));
        qtdedit->setGeometry(QRect(420, 90, 221, 27));
        linecodigo = new QLineEdit(AlugarEquipamento);
        linecodigo->setObjectName(QString::fromUtf8("linecodigo"));
        linecodigo->setGeometry(QRect(420, 40, 191, 27));
        label_7 = new QLabel(AlugarEquipamento);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(420, 70, 221, 17));
        finalizarButton = new QPushButton(AlugarEquipamento);
        finalizarButton->setObjectName(QString::fromUtf8("finalizarButton"));
        finalizarButton->setGeometry(QRect(420, 540, 221, 61));
        finalizarButton->setFont(font);
        finalizarButton->setAutoDefault(false);
        linecliente = new QLineEdit(AlugarEquipamento);
        linecliente->setObjectName(QString::fromUtf8("linecliente"));
        linecliente->setGeometry(QRect(420, 510, 221, 27));
        pushButton = new QPushButton(AlugarEquipamento);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setEnabled(true);
        pushButton->setGeometry(QRect(610, 230, 31, 31));
        QFont font1;
        font1.setPointSize(14);
        font1.setBold(true);
        font1.setItalic(true);
        font1.setWeight(75);
        pushButton->setFont(font1);
        pushButton->setMouseTracking(false);
        pushButton->setFocusPolicy(Qt::ClickFocus);
        pushButton->setAutoFillBackground(false);
        pushButton->setStyleSheet(QString::fromUtf8(""));
        pushButton->setAutoDefault(true);
        pushButton->setDefault(false);
        pushButton->setFlat(false);
        DeletButton = new QPushButton(AlugarEquipamento);
        DeletButton->setObjectName(QString::fromUtf8("DeletButton"));
        DeletButton->setGeometry(QRect(420, 260, 221, 61));
        DeletButton->setFont(font);
        label_8 = new QLabel(AlugarEquipamento);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(420, 210, 221, 17));
        LineCodDelet = new QLineEdit(AlugarEquipamento);
        LineCodDelet->setObjectName(QString::fromUtf8("LineCodDelet"));
        LineCodDelet->setGeometry(QRect(420, 230, 191, 27));
        pushButton_2 = new QPushButton(AlugarEquipamento);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setEnabled(true);
        pushButton_2->setGeometry(QRect(610, 40, 31, 31));
        pushButton_2->setFont(font1);
        pushButton_2->setMouseTracking(false);
        pushButton_2->setFocusPolicy(Qt::ClickFocus);
        pushButton_2->setAutoFillBackground(false);
        pushButton_2->setStyleSheet(QString::fromUtf8(""));
        pushButton_2->setAutoDefault(true);
        pushButton_2->setDefault(false);
        pushButton_2->setFlat(false);
        label_5 = new QLabel(AlugarEquipamento);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(20, 20, 319, 22));
        label_5->setFont(font1);
        lineEdit = new QLineEdit(AlugarEquipamento);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setEnabled(false);
        lineEdit->setGeometry(QRect(260, 20, 81, 28));
        QFont font2;
        font2.setPointSize(12);
        font2.setBold(true);
        font2.setItalic(true);
        font2.setWeight(75);
        lineEdit->setFont(font2);
        finalizarButton_2 = new QPushButton(AlugarEquipamento);
        finalizarButton_2->setObjectName(QString::fromUtf8("finalizarButton_2"));
        finalizarButton_2->setGeometry(QRect(10, 540, 161, 61));
        finalizarButton_2->setFont(font);
        finalizarButton_2->setAutoDefault(false);
        finalizarButton_3 = new QPushButton(AlugarEquipamento);
        finalizarButton_3->setObjectName(QString::fromUtf8("finalizarButton_3"));
        finalizarButton_3->setGeometry(QRect(180, 540, 161, 61));
        finalizarButton_3->setFont(font);
        finalizarButton_3->setAutoDefault(false);
        label_9 = new QLabel(AlugarEquipamento);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(-80, -30, 761, 681));
        label_9->setStyleSheet(QString::fromUtf8("border-image: url(:/WP4PH4N6.jpg);"));
        label_9->raise();
        label_6->raise();
        qtdedit->raise();
        linecodigo->raise();
        label_7->raise();
        finalizarButton->raise();
        linecliente->raise();
        layoutWidget->raise();
        listWidget->raise();
        InserirButton->raise();
        pushButton->raise();
        DeletButton->raise();
        label_8->raise();
        LineCodDelet->raise();
        pushButton_2->raise();
        label_5->raise();
        lineEdit->raise();
        finalizarButton_2->raise();
        finalizarButton_3->raise();

        retranslateUi(AlugarEquipamento);

        QMetaObject::connectSlotsByName(AlugarEquipamento);
    } // setupUi

    void retranslateUi(QDialog *AlugarEquipamento)
    {
        AlugarEquipamento->setWindowTitle(QApplication::translate("AlugarEquipamento", "Dialog", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("AlugarEquipamento", "<html><head/><body><p align=\"center\"><span style=\" font-weight:600; color:#fcfcfc;\">Nome</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("AlugarEquipamento", "<html><head/><body><p align=\"center\"><span style=\" font-weight:600; color:#f8f8f8;\">Quantidade</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("AlugarEquipamento", "<html><head/><body><p align=\"center\"><span style=\" font-weight:600; color:#f7f7f7;\">Valor</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("AlugarEquipamento", "<html><head/><body><p><span style=\" font-weight:600; color:#f5f5f5;\">PRE\303\207O TOTAL:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        linePrecoTotoal->setInputMask(QApplication::translate("AlugarEquipamento", "R$ 00000000", 0, QApplication::UnicodeUTF8));
        InserirButton->setText(QApplication::translate("AlugarEquipamento", "Inserir Equipamento", 0, QApplication::UnicodeUTF8));
        label_6->setText(QApplication::translate("AlugarEquipamento", "<html><head/><body><p><span style=\" font-weight:600; color:#fdfdfd;\">C\303\223DIGO DO EQUIPAMENTO:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        qtdedit->setInputMask(QApplication::translate("AlugarEquipamento", "99999999", 0, QApplication::UnicodeUTF8));
        qtdedit->setText(QString());
        linecodigo->setText(QString());
        label_7->setText(QApplication::translate("AlugarEquipamento", "<html><head/><body><p><span style=\" font-weight:600; color:#fafafa;\">QUANTIDADE:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        finalizarButton->setText(QApplication::translate("AlugarEquipamento", "Finalizar Aluguel", 0, QApplication::UnicodeUTF8));
        linecliente->setText(QApplication::translate("AlugarEquipamento", "Nome do Cliente", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("AlugarEquipamento", "?", 0, QApplication::UnicodeUTF8));
        DeletButton->setText(QApplication::translate("AlugarEquipamento", "Deletar Equipamento", 0, QApplication::UnicodeUTF8));
        label_8->setText(QApplication::translate("AlugarEquipamento", "<html><head/><body><p><span style=\" font-weight:600; color:#fcfcfc;\">C\303\223DIGO DO EQUIPAMENTO:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        LineCodDelet->setText(QString());
        pushButton_2->setText(QApplication::translate("AlugarEquipamento", "?", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("AlugarEquipamento", "<html><head/><body><p><span style=\" color:#ffffff;\">C\303\223DIGO DO ALUGUEL:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        finalizarButton_2->setText(QApplication::translate("AlugarEquipamento", "Cancelar Pedido", 0, QApplication::UnicodeUTF8));
        finalizarButton_3->setText(QApplication::translate("AlugarEquipamento", "Voltar ao Menu", 0, QApplication::UnicodeUTF8));
        label_9->setText(QApplication::translate("AlugarEquipamento", "'", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class AlugarEquipamento: public Ui_AlugarEquipamento {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ALUGAREQUIPAMENTO_H
