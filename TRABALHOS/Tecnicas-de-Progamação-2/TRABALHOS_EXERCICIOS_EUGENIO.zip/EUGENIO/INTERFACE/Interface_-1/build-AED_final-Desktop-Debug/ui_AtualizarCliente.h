/********************************************************************************
** Form generated from reading UI file 'AtualizarCliente.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ATUALIZARCLIENTE_H
#define UI_ATUALIZARCLIENTE_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QListWidget>
#include <QtGui/QPushButton>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AtualizarCliente
{
public:
    QComboBox *comboBox;
    QListWidget *listWidget;
    QComboBox *comboBox_2;
    QPushButton *atualizarButton;
    QPushButton *cancelarButton;
    QPushButton *deletarButton;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QLineEdit *linenome;
    QLabel *label_2;
    QLineEdit *linecpf;
    QLabel *label_5;
    QLineEdit *lineendereco;
    QLabel *label_3;
    QLineEdit *linefone;
    QLabel *label_4;

    void setupUi(QDialog *AtualizarCliente)
    {
        if (AtualizarCliente->objectName().isEmpty())
            AtualizarCliente->setObjectName(QString::fromUtf8("AtualizarCliente"));
        AtualizarCliente->resize(691, 400);
        comboBox = new QComboBox(AtualizarCliente);
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        comboBox->setGeometry(QRect(30, -30, 41, 25));
        listWidget = new QListWidget(AtualizarCliente);
        listWidget->setObjectName(QString::fromUtf8("listWidget"));
        listWidget->setGeometry(QRect(10, 40, 191, 291));
        comboBox_2 = new QComboBox(AtualizarCliente);
        comboBox_2->setObjectName(QString::fromUtf8("comboBox_2"));
        comboBox_2->setGeometry(QRect(10, 10, 51, 25));
        atualizarButton = new QPushButton(AtualizarCliente);
        atualizarButton->setObjectName(QString::fromUtf8("atualizarButton"));
        atualizarButton->setEnabled(true);
        atualizarButton->setGeometry(QRect(10, 340, 231, 51));
        QFont font;
        font.setPointSize(10);
        font.setBold(false);
        font.setItalic(true);
        font.setWeight(50);
        atualizarButton->setFont(font);
        atualizarButton->setStyleSheet(QString::fromUtf8(""));
        cancelarButton = new QPushButton(AtualizarCliente);
        cancelarButton->setObjectName(QString::fromUtf8("cancelarButton"));
        cancelarButton->setGeometry(QRect(470, 340, 211, 51));
        cancelarButton->setFont(font);
        cancelarButton->setFocusPolicy(Qt::WheelFocus);
        cancelarButton->setAutoFillBackground(false);
        deletarButton = new QPushButton(AtualizarCliente);
        deletarButton->setObjectName(QString::fromUtf8("deletarButton"));
        deletarButton->setGeometry(QRect(250, 340, 211, 51));
        deletarButton->setFont(font);
        deletarButton->setStyleSheet(QString::fromUtf8(""));
        layoutWidget = new QWidget(AtualizarCliente);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(210, 40, 471, 281));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(layoutWidget);
        label->setObjectName(QString::fromUtf8("label"));

        verticalLayout->addWidget(label);

        linenome = new QLineEdit(layoutWidget);
        linenome->setObjectName(QString::fromUtf8("linenome"));
        //linenome->setClearButtonEnabled(true);

        verticalLayout->addWidget(linenome);

        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        verticalLayout->addWidget(label_2);

        linecpf = new QLineEdit(layoutWidget);
        linecpf->setObjectName(QString::fromUtf8("linecpf"));

        verticalLayout->addWidget(linecpf);

        label_5 = new QLabel(layoutWidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        verticalLayout->addWidget(label_5);

        lineendereco = new QLineEdit(layoutWidget);
        lineendereco->setObjectName(QString::fromUtf8("lineendereco"));

        verticalLayout->addWidget(lineendereco);

        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        verticalLayout->addWidget(label_3);

        linefone = new QLineEdit(layoutWidget);
        linefone->setObjectName(QString::fromUtf8("linefone"));

        verticalLayout->addWidget(linefone);

        label_4 = new QLabel(AtualizarCliente);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(-20, -10, 711, 421));
        label_4->setStyleSheet(QString::fromUtf8("border-image: url(:/WP4PH4N6.jpg);"));
        label_4->raise();
        comboBox->raise();
        listWidget->raise();
        comboBox_2->raise();
        atualizarButton->raise();
        cancelarButton->raise();
        deletarButton->raise();
        layoutWidget->raise();

        retranslateUi(AtualizarCliente);

        QMetaObject::connectSlotsByName(AtualizarCliente);
    } // setupUi

    void retranslateUi(QDialog *AtualizarCliente)
    {
        AtualizarCliente->setWindowTitle(QApplication::translate("AtualizarCliente", "Dialog", 0, QApplication::UnicodeUTF8));
        comboBox->clear();
        comboBox->insertItems(0, QStringList()
         << QApplication::translate("AtualizarCliente", "A", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "B", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "C", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "D", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "E", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "F", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "G", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "H", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "I", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "J", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "K", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "L", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "M", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "N", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "O", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "P", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "Q", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "R", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "S", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "U", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "V", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "W", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "X", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "Y", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "Z", 0, QApplication::UnicodeUTF8)
        );
        comboBox_2->clear();
        comboBox_2->insertItems(0, QStringList()
         << QApplication::translate("AtualizarCliente", "A", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "B", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "C", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "D", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "E", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "F", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "G", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "H", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "I", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "J", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "K", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "L", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "M", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "N", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "O", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "P", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "Q", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "R", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "S", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "U", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "V", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "W", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "X", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "Y", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "Z", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("AtualizarCliente", "A-Z", 0, QApplication::UnicodeUTF8)
        );
        atualizarButton->setText(QApplication::translate("AtualizarCliente", "ATUALIZAR \n"
"CADRASTRO", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        cancelarButton->setAccessibleDescription(QString());
#endif // QT_NO_ACCESSIBILITY
        cancelarButton->setText(QApplication::translate("AtualizarCliente", "CANCELAR", 0, QApplication::UnicodeUTF8));
        deletarButton->setText(QApplication::translate("AtualizarCliente", "APAGAR \n"
"CADRASTRO", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("AtualizarCliente", "<html><head/><body><p><span style=\" color:#f9eded;\">Nome/Raz\303\243o social:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        linenome->setPlaceholderText(QString());
        label_2->setText(QApplication::translate("AtualizarCliente", "<html><head/><body><p><span style=\" color:#faf0f0;\">Cpf/Cnpj:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("AtualizarCliente", "<html><head/><body><p><span style=\" color:#f4eaea;\">Endere\303\247o:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("AtualizarCliente", "<html><head/><body><p><span style=\" color:#f2e8e8;\">Fone:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_4->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class AtualizarCliente: public Ui_AtualizarCliente {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ATUALIZARCLIENTE_H
