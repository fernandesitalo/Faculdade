#ifndef I_AL_H
#define I_AL_H


class I_Al
{
public:
    long long codigo;
    int QtdAlugada;
    I_Al();
};

#endif // I_AL_H
