#include "Aluno.h"

namespace TP2{//inicio
Aluno::Aluno():
    matricula(""),
    nome(""),
    situacao("")
{
}

QString Aluno::getAno() const{
    QString ano = matricula;
    ano.remove(4,ano.length()-4); //// funcao nova pra my life
    return ano;
}

}//fim
