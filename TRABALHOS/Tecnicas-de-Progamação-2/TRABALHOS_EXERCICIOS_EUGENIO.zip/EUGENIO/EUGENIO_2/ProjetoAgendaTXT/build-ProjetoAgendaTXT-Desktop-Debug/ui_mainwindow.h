/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QGridLayout *gridLayout;
    QLabel *label;
    QLineEdit *lineEditNome;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButtonIncluir;
    QPushButton *pushButtonExcluir;
    QPushButton *pushButtonListar;
    QLabel *label_2;
    QLineEdit *lineEditEndereco;
    QLabel *label_3;
    QLineEdit *lineEditTelefone;
    QLabel *label_4;
    QLineEdit *lineEditEmail;
    QToolBar *mainToolBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(426, 201);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        gridLayout = new QGridLayout(centralWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        label = new QLabel(centralWidget);
        label->setObjectName(QStringLiteral("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        lineEditNome = new QLineEdit(centralWidget);
        lineEditNome->setObjectName(QStringLiteral("lineEditNome"));

        gridLayout->addWidget(lineEditNome, 0, 1, 1, 2);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        pushButtonIncluir = new QPushButton(centralWidget);
        pushButtonIncluir->setObjectName(QStringLiteral("pushButtonIncluir"));

        verticalLayout->addWidget(pushButtonIncluir);

        pushButtonExcluir = new QPushButton(centralWidget);
        pushButtonExcluir->setObjectName(QStringLiteral("pushButtonExcluir"));

        verticalLayout->addWidget(pushButtonExcluir);

        pushButtonListar = new QPushButton(centralWidget);
        pushButtonListar->setObjectName(QStringLiteral("pushButtonListar"));

        verticalLayout->addWidget(pushButtonListar);


        gridLayout->addLayout(verticalLayout, 0, 3, 4, 1);

        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QStringLiteral("label_2"));

        gridLayout->addWidget(label_2, 1, 0, 1, 2);

        lineEditEndereco = new QLineEdit(centralWidget);
        lineEditEndereco->setObjectName(QStringLiteral("lineEditEndereco"));

        gridLayout->addWidget(lineEditEndereco, 1, 2, 1, 1);

        label_3 = new QLabel(centralWidget);
        label_3->setObjectName(QStringLiteral("label_3"));

        gridLayout->addWidget(label_3, 2, 0, 1, 2);

        lineEditTelefone = new QLineEdit(centralWidget);
        lineEditTelefone->setObjectName(QStringLiteral("lineEditTelefone"));

        gridLayout->addWidget(lineEditTelefone, 2, 2, 1, 1);

        label_4 = new QLabel(centralWidget);
        label_4->setObjectName(QStringLiteral("label_4"));

        gridLayout->addWidget(label_4, 3, 0, 1, 1);

        lineEditEmail = new QLineEdit(centralWidget);
        lineEditEmail->setObjectName(QStringLiteral("lineEditEmail"));

        gridLayout->addWidget(lineEditEmail, 3, 2, 1, 1);

        MainWindow->setCentralWidget(centralWidget);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        QWidget::setTabOrder(lineEditNome, lineEditEndereco);
        QWidget::setTabOrder(lineEditEndereco, lineEditTelefone);
        QWidget::setTabOrder(lineEditTelefone, lineEditEmail);
        QWidget::setTabOrder(lineEditEmail, pushButtonIncluir);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0));
        label->setText(QApplication::translate("MainWindow", "NOME", 0));
        pushButtonIncluir->setText(QApplication::translate("MainWindow", "Incluir", 0));
        pushButtonExcluir->setText(QApplication::translate("MainWindow", "Excluir", 0));
        pushButtonListar->setText(QApplication::translate("MainWindow", "Listar", 0));
        label_2->setText(QApplication::translate("MainWindow", "ENDERECO", 0));
        label_3->setText(QApplication::translate("MainWindow", "TELEFONE", 0));
        label_4->setText(QApplication::translate("MainWindow", "EMAIL", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
