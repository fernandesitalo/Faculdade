/********************************************************************************
** Form generated from reading UI file 'telaprincipal.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TELAPRINCIPAL_H
#define UI_TELAPRINCIPAL_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_TelaPrincipal
{
public:
    QWidget *centralWidget;
    QGridLayout *gridLayout;
    QHBoxLayout *horizontalLayout_2;
    QHBoxLayout *horizontalLayout;
    QPushButton *pushButtonNome;
    QPushButton *pushButtonMatricula;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButtonGeral;
    QPushButton *pushButton_3;
    QPushButton *pushButtonLimpar;
    QTextEdit *textEditSaida;
    QToolBar *mainToolBar;

    void setupUi(QMainWindow *TelaPrincipal)
    {
        if (TelaPrincipal->objectName().isEmpty())
            TelaPrincipal->setObjectName(QStringLiteral("TelaPrincipal"));
        TelaPrincipal->resize(717, 452);
        centralWidget = new QWidget(TelaPrincipal);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        gridLayout = new QGridLayout(centralWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        pushButtonNome = new QPushButton(centralWidget);
        pushButtonNome->setObjectName(QStringLiteral("pushButtonNome"));

        horizontalLayout->addWidget(pushButtonNome);

        pushButtonMatricula = new QPushButton(centralWidget);
        pushButtonMatricula->setObjectName(QStringLiteral("pushButtonMatricula"));

        horizontalLayout->addWidget(pushButtonMatricula);

        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));

        horizontalLayout->addWidget(pushButton);

        pushButton_2 = new QPushButton(centralWidget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));

        horizontalLayout->addWidget(pushButton_2);


        horizontalLayout_2->addLayout(horizontalLayout);

        pushButtonGeral = new QPushButton(centralWidget);
        pushButtonGeral->setObjectName(QStringLiteral("pushButtonGeral"));

        horizontalLayout_2->addWidget(pushButtonGeral);

        pushButton_3 = new QPushButton(centralWidget);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));

        horizontalLayout_2->addWidget(pushButton_3);

        pushButtonLimpar = new QPushButton(centralWidget);
        pushButtonLimpar->setObjectName(QStringLiteral("pushButtonLimpar"));

        horizontalLayout_2->addWidget(pushButtonLimpar);


        gridLayout->addLayout(horizontalLayout_2, 0, 0, 1, 1);

        textEditSaida = new QTextEdit(centralWidget);
        textEditSaida->setObjectName(QStringLiteral("textEditSaida"));

        gridLayout->addWidget(textEditSaida, 1, 0, 1, 1);

        TelaPrincipal->setCentralWidget(centralWidget);
        mainToolBar = new QToolBar(TelaPrincipal);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        TelaPrincipal->addToolBar(Qt::TopToolBarArea, mainToolBar);

        retranslateUi(TelaPrincipal);

        QMetaObject::connectSlotsByName(TelaPrincipal);
    } // setupUi

    void retranslateUi(QMainWindow *TelaPrincipal)
    {
        TelaPrincipal->setWindowTitle(QApplication::translate("TelaPrincipal", "TelaPrincipal", 0));
        pushButtonNome->setText(QApplication::translate("TelaPrincipal", "NOME", 0));
        pushButtonMatricula->setText(QApplication::translate("TelaPrincipal", "MATRICULA", 0));
        pushButton->setText(QApplication::translate("TelaPrincipal", "ANO/SEMESTRE/NOME", 0));
        pushButton_2->setText(QApplication::translate("TelaPrincipal", "SITUA\303\207\303\203O", 0));
        pushButtonGeral->setText(QApplication::translate("TelaPrincipal", "GERAL", 0));
        pushButton_3->setText(QApplication::translate("TelaPrincipal", "Incluir Aluno", 0));
        pushButtonLimpar->setText(QApplication::translate("TelaPrincipal", "LIMPAR", 0));
    } // retranslateUi

};

namespace Ui {
    class TelaPrincipal: public Ui_TelaPrincipal {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TELAPRINCIPAL_H
