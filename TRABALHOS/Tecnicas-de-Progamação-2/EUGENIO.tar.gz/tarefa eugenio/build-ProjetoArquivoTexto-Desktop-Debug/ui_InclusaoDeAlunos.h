/********************************************************************************
** Form generated from reading UI file 'InclusaoDeAlunos.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_INCLUSAODEALUNOS_H
#define UI_INCLUSAODEALUNOS_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_InclusaoDeAlunos
{
public:
    QGridLayout *gridLayout_2;
    QLabel *label_4;
    QGridLayout *gridLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLineEdit *lineEdit_Nome;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QLineEdit *lineEdit_Matricula;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_3;
    QLineEdit *lineEdit_Situacao;
    QPushButton *pushButton_Incluir;

    void setupUi(QDialog *InclusaoDeAlunos)
    {
        if (InclusaoDeAlunos->objectName().isEmpty())
            InclusaoDeAlunos->setObjectName(QStringLiteral("InclusaoDeAlunos"));
        InclusaoDeAlunos->resize(412, 186);
        gridLayout_2 = new QGridLayout(InclusaoDeAlunos);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        label_4 = new QLabel(InclusaoDeAlunos);
        label_4->setObjectName(QStringLiteral("label_4"));
        QFont font;
        font.setPointSize(14);
        font.setBold(true);
        font.setItalic(true);
        font.setWeight(75);
        label_4->setFont(font);

        gridLayout_2->addWidget(label_4, 0, 0, 1, 2);

        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        label = new QLabel(InclusaoDeAlunos);
        label->setObjectName(QStringLiteral("label"));

        horizontalLayout->addWidget(label);

        lineEdit_Nome = new QLineEdit(InclusaoDeAlunos);
        lineEdit_Nome->setObjectName(QStringLiteral("lineEdit_Nome"));

        horizontalLayout->addWidget(lineEdit_Nome);


        gridLayout->addLayout(horizontalLayout, 0, 0, 1, 1);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        label_2 = new QLabel(InclusaoDeAlunos);
        label_2->setObjectName(QStringLiteral("label_2"));

        horizontalLayout_2->addWidget(label_2);

        lineEdit_Matricula = new QLineEdit(InclusaoDeAlunos);
        lineEdit_Matricula->setObjectName(QStringLiteral("lineEdit_Matricula"));

        horizontalLayout_2->addWidget(lineEdit_Matricula);


        gridLayout->addLayout(horizontalLayout_2, 1, 0, 1, 1);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        label_3 = new QLabel(InclusaoDeAlunos);
        label_3->setObjectName(QStringLiteral("label_3"));

        horizontalLayout_3->addWidget(label_3);

        lineEdit_Situacao = new QLineEdit(InclusaoDeAlunos);
        lineEdit_Situacao->setObjectName(QStringLiteral("lineEdit_Situacao"));

        horizontalLayout_3->addWidget(lineEdit_Situacao);


        gridLayout->addLayout(horizontalLayout_3, 2, 0, 1, 1);


        gridLayout_2->addLayout(gridLayout, 1, 1, 1, 1);

        pushButton_Incluir = new QPushButton(InclusaoDeAlunos);
        pushButton_Incluir->setObjectName(QStringLiteral("pushButton_Incluir"));

        gridLayout_2->addWidget(pushButton_Incluir, 2, 1, 1, 1);

        QWidget::setTabOrder(lineEdit_Matricula, lineEdit_Situacao);

        retranslateUi(InclusaoDeAlunos);

        QMetaObject::connectSlotsByName(InclusaoDeAlunos);
    } // setupUi

    void retranslateUi(QDialog *InclusaoDeAlunos)
    {
        InclusaoDeAlunos->setWindowTitle(QApplication::translate("InclusaoDeAlunos", "Dialog", 0));
        label_4->setText(QApplication::translate("InclusaoDeAlunos", "INCLUS\303\203O DE NOVOS ALUNOS", 0));
        label->setText(QApplication::translate("InclusaoDeAlunos", "Nome:", 0));
        label_2->setText(QApplication::translate("InclusaoDeAlunos", "Matricula:", 0));
        lineEdit_Matricula->setInputMask(QApplication::translate("InclusaoDeAlunos", "0000.0.0000.0000-0", 0));
        lineEdit_Matricula->setText(QApplication::translate("InclusaoDeAlunos", "...-", 0));
        label_3->setText(QApplication::translate("InclusaoDeAlunos", "Situa\303\247\303\243o:", 0));
        pushButton_Incluir->setText(QApplication::translate("InclusaoDeAlunos", "INCLUIR", 0));
    } // retranslateUi

};

namespace Ui {
    class InclusaoDeAlunos: public Ui_InclusaoDeAlunos {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_INCLUSAODEALUNOS_H
