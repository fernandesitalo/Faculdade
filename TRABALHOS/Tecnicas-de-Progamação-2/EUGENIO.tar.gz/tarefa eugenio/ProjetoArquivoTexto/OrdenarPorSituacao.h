#ifndef ORDENARPORSITUACAO_H
#define ORDENARPORSITUACAO_H
#include "Aluno.h"
#include<TemplateMethodOrdenacao.h>
namespace TP2{
class OrdenarPorSituacao : public TemplateMethodOrdenacao
{
public:
    OrdenarPorSituacao(QString nomeDoArquivoNoDisco);
    bool ePrimeiro(Aluno a, Aluno b)const;
};
}

#endif // ORDENARPORSITUACAO_H
