#include "OrdenarPorAnoSemestreNome.h"

TP2::OrdenarPorAnoSemestreNome::OrdenarPorAnoSemestreNome(QString nomeDoArquivoNoDisco):
    TemplateMethodOrdenacao(nomeDoArquivoNoDisco)
{
}

//if(a.getAno() < b.getAno() && ( a.getSemestre() < b.getSemestre() && a.getNome() < b.getNome() )) return true;
/// ANO - SEMESTRE - NOME
bool TP2::OrdenarPorAnoSemestreNome::ePrimeiro(TP2::Aluno a, TP2::Aluno b) const
{
    if(a.getAno() < b.getAno()) return true;
    if(a.getAno() == b.getAno() && a.getSemestre() < b.getSemestre()) return true;
    if(a.getAno() == b.getAno() && a.getSemestre() == b.getSemestre() && a.getNome() < b.getNome()) return true;
    return false;
}
