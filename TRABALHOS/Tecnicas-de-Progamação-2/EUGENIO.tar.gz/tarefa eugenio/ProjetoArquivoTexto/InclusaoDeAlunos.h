#ifndef INCLUSAODEALUNOS_H
#define INCLUSAODEALUNOS_H
#include <vector>
#include "Aluno.h"
#include <QDialog>

namespace Ui {
class InclusaoDeAlunos;
}

class InclusaoDeAlunos : public QDialog
{
    Q_OBJECT

public:
    explicit InclusaoDeAlunos(QString NomeDoArquivo,QWidget *parent = 0);
    ~InclusaoDeAlunos();

private slots:
    void on_pushButton_Incluir_clicked();

    void ColocaNoArquivo();

    QString MontaLinhaDoAquivo(TP2::Aluno &aluno);

private:
    Ui::InclusaoDeAlunos *ui;
    std::vector<TP2::Aluno> *Vector;
    QString NomeDoArquivo;
};

#endif // INCLUSAODEALUNOS_H
