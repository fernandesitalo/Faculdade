#include "InclusaoDeAlunos.h"
#include "ui_InclusaoDeAlunos.h"
#include <fstream>
InclusaoDeAlunos::InclusaoDeAlunos(QString NomeDoArquivo,QWidget *parent) :
    QDialog(parent),
    ui(new Ui::InclusaoDeAlunos)
{

    ui->setupUi(this);
    Vector = new std::vector<TP2::Aluno>;
    this->NomeDoArquivo = NomeDoArquivo;
}

InclusaoDeAlunos::~InclusaoDeAlunos()
{
    ColocaNoArquivo();
    delete Vector;
    delete ui;    
}

void InclusaoDeAlunos::on_pushButton_Incluir_clicked()
{
    TP2::Aluno aluno;
    aluno.setNome(ui->lineEdit_Nome->text());
    aluno.setMatricula(ui->lineEdit_Matricula->text());
    aluno.setSituacao(ui->lineEdit_Situacao->text());

    QMessageBox::information(this,"ATENCAO","Esteja ciente que os dados estão certos... Versão 2.0 com validacao de Matricula!");
    Vector->push_back(aluno);
    ui->lineEdit_Nome->clear();
    ui->lineEdit_Matricula->clear();
    ui->lineEdit_Situacao->clear();
}

void InclusaoDeAlunos::ColocaNoArquivo()
{
    std::fstream arq (NomeDoArquivo.toStdString().c_str(),std::ios::app);
    if(!arq.is_open()){
        std::fstream aux(NomeDoArquivo.toStdString().c_str(),std::ios::out);
        aux.close();
        std::fstream arq (NomeDoArquivo.toStdString().c_str(),std::ios::app);
    }

    QString texto;

    for(std::vector<TP2::Aluno>::iterator it = Vector->begin() ; it != Vector->end() ; ++it){
        texto+= MontaLinhaDoAquivo(*it);
    }

    //arq.write(texto.toStdString().c_str(),sizeof texto.toStdString().c_str());
    arq <<texto.toStdString().c_str();
    arq.close();
}

QString InclusaoDeAlunos::MontaLinhaDoAquivo(TP2::Aluno &aluno)
{
    QString saida;
    saida += aluno.getMatricula();
    saida += " ; ";
    saida += aluno.getNome();
    saida += " ; ";
    saida += aluno.getSituacao();
    saida += "\n";
    return saida;

}
