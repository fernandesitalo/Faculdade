#ifndef TELAALTERAR_H
#define TELAALTERAR_H

#include <QDialog>
#include "Contato.h"

namespace Ui {
class TelaAlterar;
}

class TelaAlterar : public QDialog
{
    Q_OBJECT

public:
    explicit TelaAlterar(QWidget *parent = 0);
    explicit TelaAlterar(agenda::Contato &Individuo,QWidget *parent = 0);
    ~TelaAlterar();
private:
    void SetarDados(agenda::Contato &A);

private slots:
    void on_pushButtonAlterar_clicked();

    void on_pushButtonExluir_clicked();

    void on_pushButtonCancelar_clicked();

private:
    Ui::TelaAlterar *ui;
    agenda::Contato *CT;
};

#endif // TELAALTERAR_H
