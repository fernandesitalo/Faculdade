#include "TelaAlterar.h"
#include "ui_TelaAlterar.h"
#include "Contato.h"
#include "ContatoPersistencia.h"
#include <QMessageBox>

TelaAlterar::TelaAlterar(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::TelaAlterar)
{
    ui->setupUi(this);
}

TelaAlterar::TelaAlterar(agenda::Contato &Individuo,QWidget *parent):
    QDialog(parent),
    ui(new Ui::TelaAlterar)
{
    ui->setupUi(this);
    SetarDados(Individuo);
    CT = &Individuo;
}

TelaAlterar::~TelaAlterar()
{
    delete ui;
}

void TelaAlterar::SetarDados(agenda::Contato &A)
{
    ui->lineEditEmail->setText(A.getEmail());
    ui->lineEditEndereco->setText(A.getEndereco());
    ui->lineEditNome->setText(A.getNome());
    ui->lineEditTelefone->setText(QString::number(A.getTelefone()));
}

void TelaAlterar::on_pushButtonAlterar_clicked()
{
    try{
        CT->setEmail(ui->lineEditEmail->text());
        CT->setEndereco(ui->lineEditEndereco->text());
        CT->setTelefone(ui->lineEditTelefone->text().toLongLong());
        if(ui->lineEditNome->text() == CT->getNome()){
            agenda::ContatoPersistencia agendaContato("dados.txt");
            agendaContato.alterar(*CT);
        }
        else{
            agenda::ContatoPersistencia agendaContato("dados.txt");
            agendaContato.excluir(CT->getNome());
            CT->setNome(ui->lineEditNome->text());
            agendaContato.incluir(*CT);
        }
    }catch(...){
        QMessageBox::critical(this,"ops!","Houve Um Erro!");
    }
    this->hide();
}

void TelaAlterar::on_pushButtonExluir_clicked()
{
    try{
        agenda::ContatoPersistencia agendaContato("dados.txt");
        agendaContato.excluir(CT->getNome());
    }catch(...){
       QMessageBox::critical(this,"ops!","Houve Um Erro!");
    }
    this->hide();
}

void TelaAlterar::on_pushButtonCancelar_clicked()
{
    this->hide();
}
