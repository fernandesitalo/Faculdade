#include "OrdenarPorSituacao.h"

namespace TP2{

OrdenarPorSituacao::OrdenarPorSituacao(QString nomeDoArquivoNoDisco) :
    TemplateMethodOrdenacao(nomeDoArquivoNoDisco)
{

}

bool OrdenarPorSituacao::ePrimeiro(Aluno a,Aluno b) const
{
    return (a.getSituacao() < b.getSituacao());
}

} /// FIM NAMESPACE TP2
