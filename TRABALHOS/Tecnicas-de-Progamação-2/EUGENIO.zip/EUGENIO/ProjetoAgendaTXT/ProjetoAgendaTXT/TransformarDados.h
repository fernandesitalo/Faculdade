#ifndef TRANSFORMARDADOS_H
#define TRANSFORMARDADOS_H
#include<QString>
namespace agenda{//inicio


class TransformarDados    // classe abstrada - todos que herdarem devem implementar tais dados
{
public:
    virtual void montarObjeto(QString &str) = 0;
    virtual QString desmontarObjeto()const = 0;
};
}//fim
#endif // TRANSFORMARDADOS_H
