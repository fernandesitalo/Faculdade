#include "ContatoPersistencia.h"
namespace agenda{//inicio
ContatoPersistencia::ContatoPersistencia(QString nomeDoArquivoNoDisco):
    nomeDoArquivoNoDisco(nomeDoArquivoNoDisco)
{

}


/// app - adcionar ao final do arquivo
/// out - cria um novo se existir para gravar
/// in - abre para leitura




void ContatoPersistencia::incluir(Contato &objeto) const
{
    std::ofstream arquivoAgenda; /// inicializa o fluxo

    arquivoAgenda.open(nomeDoArquivoNoDisco.toStdString().c_str(),
                                   std::ios::out|std::ios::app);
    if(!arquivoAgenda.is_open()){
        throw QString("Arquivo de Agenda nao foi aberto - Metodo incluir");
    }
    arquivoAgenda<<objeto.desmontarObjeto().toStdString()+"\n";
    /// imprime no arquivo, poiis mudou o fluxo do progama....

    arquivoAgenda.close(); /// finaliza o fluxo criado
}





////////////////////////   METODO DE EXLUIR DIFERENTE
///
void ContatoPersistencia::excluir(QString nome) const{
    try
    {
        std::stack<agenda::Contato> pilha;
        std::ifstream arquivoAgenda; //// ABERTURA PARA LEITURA

        arquivoAgenda.open(nomeDoArquivoNoDisco.toStdString().c_str()); // VALIDA ABERTURA
        if(!arquivoAgenda.is_open()){
            throw QString("Arquivo de Agenda nao foi aberto");
        }        

        std::string linha;

        getline(arquivoAgenda,linha);
        while(!arquivoAgenda.eof()){
            agenda::Contato objeto;
            QString str = QString::fromStdString(linha);
            objeto.montarObjeto(str);            
            if(objeto.getNome() != nome) pilha.push(objeto);

            getline(arquivoAgenda,linha);
        }
        arquivoAgenda.close();


        std::ofstream arquivoAgenda2; /// ABRE PARA ESCRITA - SE JA EXISTIR CRIA DNV LIMPINHO

        arquivoAgenda2.open(nomeDoArquivoNoDisco.toStdString().c_str());
        if(!arquivoAgenda2.is_open()){
            throw QString("Arquivo de Agenda nao foi aberto");
        }

        while(!pilha.empty()){ /// TACA NO ARQUIVO DE NOVO
            agenda::Contato objeto = pilha.top();
            arquivoAgenda2<<objeto.desmontarObjeto().toStdString()+"\n";
            pilha.pop();
        }

        arquivoAgenda2.close();
    } catch (QString &erro) {
        throw(erro);
    }
}

// Metodo para comparação dos objetos Contatos a ser
// utilizado pelo metodo sort da list para ordenar
// os contatos da lista
bool operator < (agenda::Contato &p1, agenda::Contato &p2)
{
    if (p1.getNome()<p2.getNome())
        return true;
    else return false;
}

std::list<Contato>* ContatoPersistencia::listagem() const{

    try {
        std::ifstream arquivoAgenda;
        arquivoAgenda.open(nomeDoArquivoNoDisco.toStdString().c_str());

        if(!arquivoAgenda.is_open()){
            throw QString("Arquivo de Agenda nao foi aberto");
        }

        std::list<agenda::Contato> *lista = new std::list<Contato>();
        std::string linha;

        getline(arquivoAgenda,linha);
        while(!arquivoAgenda.eof()){
            agenda::Contato objeto;
            QString str = QString::fromStdString(linha);
            objeto.montarObjeto(str);///// monta linha
            lista->push_back(objeto);
            getline(arquivoAgenda,linha);
        }

        arquivoAgenda.close();
        lista->sort();
        return lista;

    } catch (QString &erro) {
        throw(erro);
    }
}


}//fim

