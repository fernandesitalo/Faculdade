package server;
import javax.jws.WebService;
import java.util.Vector;

@WebService(endpointInterface = "server.StoreClient")
public class StoreClientImpl implements StoreClient {
    Vector<Integer> products;
    Vector<Integer> purchases;
    
    public StoreClientImpl(Vector<Integer> x, Vector<Integer> y){
        this.products = x;
        this.purchases = y;
    }
    
     public String showItens(){
        String list = new String();
        int idx = 1;
        for(int x : products){
            if(list.isEmpty() == false) list = list + ',';
            list = list + idx + ":" + x;
            idx++;
        }
        return  list;
    }
    
    public String showIten(int x){
        return products.get(x-1).toString();
    }
    
    public boolean byItem(int idx){
        
        this.purchases.add(this.products.remove(idx-1));
        return true;
    }
    
}
