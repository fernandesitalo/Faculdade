package server;
import javax.jws.WebService;
import java.util.ArrayList;
import java.util.Vector;

@WebService(endpointInterface = "server.Store")
public class StoreImpl implements Store {
    Vector<Integer> products;
    Vector<Integer> purchases;
    public StoreImpl(Vector<Integer> x, Vector<Integer> y){
        products = x;
        purchases = y;
    }
    
    public boolean insert(int x){
        products.add(x);
        return true;
    }
    
    public  boolean delete(int x){
        products.remove(x-1);
        return true;
    }
    
    public String showItens(){
        String list = new String();
        int idx = 1;
        for(int x : products){
            if(list.isEmpty() == false) list = list + ',';
            list = list + idx + ":" + x;
            idx++;
        }
        return  list;
    }
    
    public String showIten(int x){
        return products.get(x-1).toString();
    }
    
    public String showPurchases(){
        String list = new String();
        int idx = 1;
        for(int x : purchases){
            if(list.isEmpty() == false) list = list + ',';
            list = list + idx + ":" + x;
            idx++;
        }
        return  list;
    }
}