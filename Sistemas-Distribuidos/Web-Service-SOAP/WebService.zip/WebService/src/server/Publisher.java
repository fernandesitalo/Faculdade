package server;
import javax.xml.ws.Endpoint;
import java.util.ArrayList;
import java.util.Vector;

public class Publisher {
    public static void main(String[] args){
        Vector<Integer> db1 = new Vector<Integer>();
        Vector<Integer> db2 = new Vector<Integer>();
        StoreImpl obj1 = new StoreImpl(db1, db2);
        StoreClientImpl obj2 = new StoreClientImpl(db1, db2);
        Endpoint.publish("http://127.0.0.1:7777/server.client", obj2);
        Endpoint.publish("http://127.0.0.1:7777/server.admin", obj1);
        System.out.println("Running");
    }
}