package server;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;
import java.net.URL;

class Client {
  public static void main(String args[]) throws Exception {
    URL url = new URL("http://127.0.0.1:7777/server.client?wsdl");
    QName qname = new QName("http://server/","StoreClientImplService");
    Service ws = Service.create(url, qname);
    StoreClient x = ws.getPort(StoreClient.class);
    System.out.println(x.showItens());
  }
}
