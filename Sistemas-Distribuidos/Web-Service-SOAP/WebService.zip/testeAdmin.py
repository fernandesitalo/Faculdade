import zeep
import os
wsdl = 'http://127.0.0.1:7777/server.admin?wsdl'
client = zeep.Client(wsdl=wsdl)

while(True):
  os.system('clear')
  print("Escolha a opcao;")
  print("1 - inserir item")
  print("2 - deletar item")
  print("3 - listar todos itens")
  print("4 - listar um unico item")
  print("5 - Mostrar compras efetuadas")
  print("0 - sair\n\n")
  print("Digite a opcao desejada: ")
  opcao = int(input())
  if opcao == 1:
    print("digite o codigo do item: ");
    cod = int(input())
    print(client.service.insert(cod))
  elif opcao == 2:
    print("digite o indice do item a ser deletado: ");
    ind = int(input())
    print(client.service.delete(ind))
  elif opcao == 3:
    temp = client.service.showItens().split(',')
    for i in temp:
      print(i)
  elif opcao == 4:
    print("digite o indice do item: ")
    ind = int(input())
    print(client.service.showIten(ind))
  elif opcao == 5:
    print(client.service.showPurcharses())
  elif opcao == 0:
    break
  else:
    print("opcao invalida!")
  print("aperte enter para continuar")
  input()

