import zeep,os

wsdl = 'http://127.0.0.1:7777/server.client?wsdl'
client = zeep.Client(wsdl=wsdl)
#  print(client.service.showItens())

#didatico, sem validacoes!
while(True):
  os.system('clear')
  print("Escolha a opcao;")
  print("1 - comprar um item")
  print("2 - listar todos itens")
  print("3 - listar um unico item")
  print("0 - sair\n\n")
  print("Digite a opcao desejada: ")
  opcao = int(input())
  if opcao == 1:
    print("digite o codigo do item a ser comprado: ");
    cod = int(input())
    print(client.service.byItem(cod))
  elif opcao == 2:
    temp = client.service.showItens()
    if temp == None:
      print("Lista de Itens vazia!")
    else:
      temp = temp.split(',')
      for i in temp:
        print(i)
  elif opcao == 3:
    print("digite o indice do item: ")
    ind = int(input())
    print(client.service.showIten(ind))
  elif opcao == 0:
    break
  else:
    print("opcao invalida!")
  print("aperte enter para continuar")
  input()
