
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class Consumidor extends Thread{
	BufferRemoto Buffer;
	Registry registry;
	
	public Consumidor(){
		try{
			registry = LocateRegistry.getRegistry("localhost", 4321); // obtem registro no rmi register
			Buffer = (BufferRemoto) registry.lookup("Buffer");	// --- ok
			System.err.println("Consumidor inicializado com sucesso!");
		}
		catch(Exception error){
			System.err.println("excecao construtor consumidor!");
			error.printStackTrace();
		}
	}
	
	public void consumir(){
		try{
			String response = Buffer.remover(); // consumidor consome, então retira
			System.out.println("Resposta Buffer Consumidor: " + response);
		}
		catch(Exception error){
			System.err.println("excecao quando o consumidor estava consumindo!");
			error.printStackTrace();				
		}
	}
	
	public void run(){
		while(true){
			try{
				this.consumir();
				int time = (int) (Math.random() * 5000);
				Thread.sleep(time);
			}catch(Exception E){
				E.printStackTrace();
			}
		}
	}
	
	public static void main(String args[]) {
		// quantas threads eu quiser
		Consumidor C = new Consumidor();
		C.start();
	}
}
