import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;
// copiei e colei
public class BufferRemotoImpl implements BufferRemoto {
    private final List<Integer> buffer = new ArrayList<>();
    int limite = 5;
    
    public BufferRemotoImpl(){}
    
    @Override
    public boolean inserir(int item) throws RemoteException {
        if (buffer.size() < limite){
            buffer.add(item);
            return true;
        }
        else{
            return false;
        }
    }

    @Override
    public String remover() throws RemoteException {
        if (buffer.size() >= 1) {
			return buffer.remove(0).toString();
        }
        else {
            return "ERRO! Buffer vazio!";
        }
    }
}

