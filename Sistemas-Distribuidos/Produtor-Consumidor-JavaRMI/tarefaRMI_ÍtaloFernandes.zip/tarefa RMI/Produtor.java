import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Random;

public class Produtor extends Thread{
	BufferRemoto Buffer;
	Registry registry;
	
	public Produtor(){
		try{
			registry = LocateRegistry.getRegistry("localhost", 4321);// obtem o registro dessa porta e desse host
			Buffer = (BufferRemoto) registry.lookup("Buffer");	// --- ok
			System.err.println("Produtor inicializado com sucesso!");
		}
		catch(Exception error){
			System.err.println("excecao construtor produtor!");
			error.printStackTrace();
		}
	}
	
	public void produzir(){
		Random rand = new Random();
		try{
			Integer item = rand.nextInt(1000);// tratar ou nao para continuar tentando insetir este item ate ele ser inserido?!!!
			while(true){
				boolean confirmacao = Buffer.inserir(item); // produtor produz... insere
				if(confirmacao == true){
					System.out.println("PRODUTOR PRODUZIU E COLOCOU NO BUFFER O ITEM " + item);
					break;
				}else{
					System.out.println("BUFFER CHEIO!!");	
				}
			}
		}
		catch(Exception error){
			System.err.println("error ao produzir!");
			error.printStackTrace();
		}
	}
	
	public void run(){
    while(true){
		try{
			this.produzir();
			int time = (int) (Math.random() * 5000);
			Thread.sleep(time);
		}
		catch(Exception error){
			error.printStackTrace();
		}
	}
  }
	
		
    public static void main(String args[]) {
		// colocar quantas threads eu quiser
		Produtor P = new Produtor();
		P.start();
	}
}
