import java.rmi.Remote;
import java.rmi.RemoteException;
// copiei e colei
public interface BufferRemoto extends Remote {
    public boolean inserir (int i) throws RemoteException;
    public String remover() throws RemoteException;
}
