import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;

public class Servidor{
	
    public static void main(String args[]) {
        
        try {
            BufferRemotoImpl obj = new BufferRemotoImpl();

			// cria e registra no rmi register
            LocateRegistry.createRegistry(4321); 
            Registry registry = LocateRegistry.getRegistry(4321);

			
            BufferRemoto stub = (BufferRemoto) UnicastRemoteObject.exportObject(obj, 0); // retorna um stub que se cominica com o objeto remoto.
            //Exporta o objeto remoto para disponibilizá-lo para receber chamadas, usando a porta fornecida específica.          
 
            registry.rebind("Buffer", stub); //Substitui a ligação do especificado nome e registro pela referência remota fornecida.
            System.err.println("Servidor esta rodando");
        }
        catch (Exception e) {
            System.err.println("Server exception: " + e.toString());
            e.printStackTrace();
        }
    }
}
