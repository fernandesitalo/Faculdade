import json
import requests
import hashlib
import ast


if __name__ == '__main__':
    while True:
        msg = {'nome' : 'cliente1'}
        try:
            response = requests.get('http://127.0.0.1:5000/bruteforce/task',json = msg) 
        except:
            print("Parece que o WebService foi finalizado! :/")
            exit(0)
        
        block = eval(response.content)
        if len(block) == 0:
            continue
            
        hash_key = block['hash_key']
        passwords = block['passwords']
        
        for password in passwords:
            hsh_calc = hashlib.md5(password.encode('utf-8')).hexdigest()
            # ~ print(" -----> ", password)
            if hash_key == hsh_calc:
                # mandar um post avisando que recebeu
                msg = {'found' : True,'password' : password}
                requests.post('http://127.0.0.1:5000/bruteforce/response', json = msg, headers = {'Content-Type' : 'application/json'})
				
        msg = {'found' : False, 'password' : ''}
        requests.post('http://127.0.0.1:5000/bruteforce/response', json = msg)




