import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import Buffer.Buffer;

/*
	Corpo da mensagem --> [id - tipo_do_cliente - mensagem_de_status - data] 
		INDICE STATUS DA MENSAGEM
     0 - colocar no buffer
     1 - colocou certo
     2 - deu erro pra colocar
     3 - Retirar do buf
     4 - retirou certo
     5 - deu erro pra retirar
*/

class WorkerTCP implements Runnable {
    int id;
    Socket novaConexao;
    InputStream in;
    OutputStream out;
    Buffer buf;
    
    public WorkerTCP(int id, Socket conexaoCliente, Buffer buf) throws Exception {
        this.id = id;
        this.novaConexao = conexaoCliente;
        this.in = novaConexao.getInputStream();
        this.out = novaConexao.getOutputStream();
        this.buf = buf;
    }
        
    @Override
    public void run() {
      while (true) {
					try {
						// DESMONTA MENSAGEM.
						byte[] vetorbyte = new byte [500];
						in.read(vetorbyte);
						String aux = new String(vetorbyte).trim();
						String arr[] = aux.split("-");
						int client_id = Integer.parseInt(arr[0]);
						int client_type = Integer.parseInt(arr[1]);
						int status = Integer.parseInt(arr[2]);
						int data = Integer.parseInt(arr[3]);
						// MENSAGEM DESMONTADA
								 
						if(client_type == 1){
							tratar_produtor(client_id, data);
						}
						else{
							tratar_consumidor(client_id);
						}
				}
				catch(Exception erro) {
								erro.printStackTrace();
				}
			}
    }
    
    public void debug(String x){
      System.out.println(">> " + x);
    }
    
    public void tratar_consumidor(int id_consumidor){
      String resp;
      try{
        int data = buf.get_front();
        resp = id + "-0-4-" + data;// MONTA MENSAGEM
        debug("Consumidor " + id_consumidor + " consumiu o dado " + data + " do buffer!!");
      }catch(Exception x){
        resp = id + "-0-5-" + 0;	// MONTA MENSAGEM
        debug("Consumidor " + id_consumidor + " tentou consumir (do buffer) e deu errado!");
      }
      try {
        debug("Respondendo ao consumidor..."+resp);
        out.write(resp.getBytes());
        out.flush();
        
      }catch(Exception x){
        x.printStackTrace();
      }
    }
    
    public void tratar_produtor(int id_produtor,int data){
      String resp;
      try{
        buf.push_back(data);
        debug("TAMANHO ATUAL DO BUFFER " + buf.size());
        resp = id + "-0-1-" + 0;
        debug("Produtor " + id_produtor + " colocou o dado " + data + " no buffer!!!");
      }catch(Exception x){
        resp = Integer.toString(id) + "-0-2-" + Integer.toString(0);
        debug("Produtor " + id_produtor + " tentou colocar o dado " + data + " no buffer e deu errado!!!");
      }
      
      try {
        out.write(resp.getBytes());
        out.flush();
      }catch(Exception x){
        x.printStackTrace();
      }
    }
}
        
public class BufServer {
    public static void main(String[] args) throws Exception {
        int size_buf = 10;
        Buffer buf = new Buffer(size_buf);
        ServerSocket server = new ServerSocket (5665);
        int novoId = 1;
        while (true) {
            Socket novaConexao = server.accept();
            WorkerTCP novoWorker = new WorkerTCP(novoId, novaConexao, buf);
            novoId++;
            Thread novaThread = new Thread(novoWorker);
            novaThread.start();
        }
    }
}
