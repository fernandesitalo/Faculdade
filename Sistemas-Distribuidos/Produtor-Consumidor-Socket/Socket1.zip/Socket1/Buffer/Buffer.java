package Buffer;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ArrayBlockingQueue;
import java.io.*;

public class Buffer {
    private BlockingQueue<Integer> buf;
    private int tam;
       
    public Buffer(int tam){ // tamanho maximo do buffer
      this.tam = tam;
      this.buf = new ArrayBlockingQueue(tam, true);
    }
    
    public int size(){ //retorna TAMANHO da fila
			return buf.size();
    }
    
    public  void push_back(Integer element){ 
				this.buf.add(element); // IMPORTANTE: esse metodo lança excessao quanto esta cheio....
    }
    
    public Integer get_front(){ // REMOVE e RETORNA o primeiro elemento da FILA
      try{
        return this.buf.remove();
      }catch(Exception X){
        X.printStackTrace();
      }
      return null;
    }
}
