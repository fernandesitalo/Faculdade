import java.net.Socket;
import java.io.InputStream;
import java.io.OutputStream;

public class Consumidor extends Thread{
    
    private int id;
    Socket conexao;
    InputStream in;
		OutputStream out;
    
    public Consumidor(int id){
        try {
          this.id = id;
          this.conexao = new Socket("localhost", 5665);
          this.in = conexao.getInputStream();
          this.out = conexao.getOutputStream();
        }catch(Exception X){
          X.printStackTrace();
        }
        debug("COMUNICAÇÃO CONSUMIDOR OK!");
    }
    
    private void Consumir(){
      String send,aux;
      try{
				// MONTA MENSAGEM
        send = id + "-2-3-7";
        
        // ENVIA MENSAGEM
        out.write(send.getBytes());
        out.flush();
        debug("Consumidor " + id + " quer consumir. Requisitando . . .");
        
        // ESCUTA PORTA - recebe
        byte[] vetorbyte = new byte [500];
        in.read(vetorbyte);
        aux = new String(vetorbyte).trim();
        debug("Pedido do Consumidor " + id + " escutado!");
        
        // DESMONTA MENSAGEM
        String arr[] = aux.split("-",4);
        int client_id = Integer.parseInt(arr[0]);
        int client_type = Integer.parseInt(arr[1]);
        int status = Integer.parseInt(arr[2]);
        int data = Integer.parseInt(arr[3]);
        
        if(status == 5){
          System.out.println("Consumidor " + id + " não conseguiu consumir! :/");
        }else{
          System.out.println("Consumidor " + id + " conseguiu consumir! =D");
        }
      }catch(Exception X){
				debug("ERRO AO CONSUMIR!");
        X.printStackTrace();
      }
    }
    
    
    public void debug(String x){
      System.out.println(">> " + x);
    }
    
    public void run(){
      while(true){
        try{
          this.Consumir();  
          int time = (int) (Math.random() * 5000);
          Thread.sleep(time);
        }catch(Exception E){
            E.printStackTrace();
        }
      }
    }
       
  public static void main(String[] args) throws Exception{
		int qtd_con = 3;
		for(int i = 0 ; i < qtd_con ; ++i){
			Consumidor cons = new Consumidor(1+i);
			Thread novaThread = new Thread(cons);
			novaThread.start();
		}
  }
}
