import java.net.Socket;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Random;


public class Produtor extends Thread {
   private int id;    
   Socket conexao;
   InputStream in;
   OutputStream out;
   
   public Produtor(int id){
      try {
          this.id = id;
          this.conexao = new Socket("localhost", 5665);
          this.in = conexao.getInputStream();
          this.out = conexao.getOutputStream();
        }catch(Exception X){
          X.printStackTrace();
        }
        debug("CONEXAO PRODUTOR OK!");
   }
   
    public void debug(String x){
      System.out.println(">> " + x);
    }
    
   
   private void Produzir(){
      Random rand = new Random();
      Integer dado = rand.nextInt(300);
      String send,aux;
      
      int qtd = 10, i;
      for(i = 0; i < qtd; i++){
        try{
					// ENVIA SOLICITAÇAO PARA COLOCAR NO BUFFER
          debug("Produtor " + id + " quer colocar no buffer!"); 
          send = this.id + "-1-0-" + dado;
					out.write(send.getBytes()); // comunica que vai colocar no buffer
					out.flush();
					
					// ESCUTA PORTA - recebe
					byte[] vetorbyte = new byte [100];
					in.read(vetorbyte);
          debug("Produtor " + id + " foi escutado!!");
          
          // DESMONTA MENSAGEM
					aux = new String(vetorbyte).trim();
					String arr[] = aux.split("-");
          int client_id = Integer.parseInt(arr[0]);
          int client_type = Integer.parseInt(arr[1]);
          int status = Integer.parseInt(arr[2]);
          int data = Integer.parseInt(arr[3]);
          
          if(status == 1) break;
          debug("Produtor " + id + " - Tentativa " + (i+1) + " falhou!!!");
          
        }catch(Exception X){
          X.printStackTrace();
        }
      }
      
      if(i >= qtd) debug("Produtor " + id + " - Limite de tentativas excedidas");
      else debug("Produtor " + id + " - Tentativa " + (i+1) + " deu certo!!! 	HERE(!)");
   }
   
   public void run(){
    while(true){
			try{
					this.Produzir();
					int time = (int) (Math.random() * 5000);
					Thread.sleep(time);
			}
			catch(Exception X){
			X.printStackTrace();
			}
    }
  } 
   
  public static void main(String[] args) throws Exception{
		int qtd_prod = 5;
		for(int i = 0 ; i < qtd_prod ; ++i){
      Produtor prod = new Produtor(i+1);
      Thread novaThread = new Thread(prod);
      novaThread.start();
		}
  }
}
